import matplotlib.pyplot as plt
from fooof import FOOOF
from fooof.sim.gen import gen_aperiodic
from fooof.plts.spectra import plot_spectra
from fooof.plts.annotate import plot_annotated_peak_search
import os
import pandas as pd
import mne
# import matplotlib.pyplot as plt 
##from scipy import signal,fft
import numpy as np
from mne.io import RawArray, read_raw_edf
# from mne.channels import read_montage
from mne import create_info, concatenate_raws, pick_types
from mne.filter import notch_filter
from scipy import signal, stats
import csv
from collections import Counter
from imblearn.over_sampling import SMOTE
import random


def ttest_for_p_value(cls_a, cls_b):
    # 当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性。
    p_std = stats.levene(cls_a, cls_b)
    if p_std[1] > 0.05:
        p_ttest = stats.ttest_ind(cls_a, cls_b)
    else:
        p_ttest = stats.ttest_ind(cls_a, cls_b, equal_var=False)
    p_value = p_ttest[1]
    return p_value


data_dir = r'E:\pythonProject\Seizure_forecasting\mnt\data4\datasets\seizure\CHB-MIT'
result_dir = r'E:\pythonProject\Seizure_forecasting\fooof-main-new\statistics_result'  # 参数的特征值
if os.path.exists(result_dir):
    pass
else:
    os.makedirs(result_dir)
onset = pd.read_csv(os.path.join(data_dir, 'seizure_summary.csv'), header=0)
# 使用case 1的03, 04, 15, 18，26这5个edf.
# 因为16和21的前期数据太短.osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']
osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']
osfilenames = list(osfilenames)

segment = pd.read_csv(os.path.join(data_dir, 'segmentation.csv'), header=None)
nsfilenames = list(segment[segment[1] == 0][0])

# chs = [ u'FP1-F7',u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
#         u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4',u'F4-C4', 
#         u'C4-P4', u'P4-O2', u'FP2-F8',u'F8-T8', u'T8-P8', 
#         u'P8-O2', u'FZ-CZ', u'CZ-PZ', u'T7-FT9',u'FT9-FT10', u'FT10-T8']

sampRate = 256
len_t = 5
segLen = sampRate * len_t

# case_files = [f for f in os.listdir(data_dir) if f.startswith('chb')] #chb03拟合不了
# case_files = ['chb02', 'chb03', 'chb10', 'chb14', 'chb16', 'chb18']
case_files = ['chb03']

for tempcase in case_files:

    char_to_remove = 'chb'
    target = tempcase.replace(char_to_remove, '')

    if target in ['13', '16']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0', u'FZ-CZ', u'CZ-PZ']

    elif target in ['04']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'P8-O2',
               u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT10-T8']

    elif target in ['09']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'P8-O2',
               u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT9-FT10', u'FT10-T8']

    else:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0',
               u'P8-O2', u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT9-FT10', u'FT10-T8']

    dir = os.path.join(data_dir, tempcase)

    result_dir_case_ict = os.path.join(result_dir, 'ictal', tempcase)
    if not os.path.exists(result_dir_case_ict):
        os.makedirs(result_dir_case_ict)
        print("case Folder for result created successfully!")
    else:
        print("case Folder for result already exists!")

    result_dir_case_int = os.path.join(result_dir, 'interictal', tempcase)
    if not os.path.exists(result_dir_case_int):
        os.makedirs(result_dir_case_int)
        print("case Folder for result created successfully!")
    else:
        print("case Folder for result already exists!")

    result_dir_aperi = os.path.join(result_dir, 'aperiodic', tempcase)
    if not os.path.exists(result_dir_aperi):
        os.makedirs(result_dir_aperi)
        print("Aperiodic component Folder for result created successfully!")
    else:
        print("Aperiodic component Folder for result already exists!")

    text_files = [f for f in os.listdir(dir) if f.endswith('.edf')]

    filesnames_ict = [filename for filename in text_files if filename in osfilenames]
    filesnames_int = [filename for filename in text_files if filename in nsfilenames]

    data_ict = {}
    off_ict = {}
    off_ict_smo = {}
    exp_ict = {}
    exp_ict_smo = {}
    data_int = {}
    off_int = {}
    off_int_smo = {}
    exp_int = {}
    exp_int_smo = {}

    totalfiles = len(filesnames_ict)
    print('case %s Total ictal files %d' % (tempcase, totalfiles))

    for filename in filesnames_ict:
        rawEEG = read_raw_edf('%s/%s' % (dir, filename), verbose=0, preload=True)
        # preload如果为True，则数据将被预加载到内存中
        rawEEG.pick_channels(chs)
        tmp = rawEEG.to_data_frame()
        tmp = tmp.values[:, 1:]
        tmp = tmp.T
        assert tmp.shape[0] == len(chs)
        print('=========================================')
        print('The ictal-file channels number is alright: 21')
        print('=========================================')

        off_ict[filename] = {}
        off_chs = off_ict[filename]
        exp_ict[filename] = {}
        exp_chs = exp_ict[filename]
        off_ict_smo[filename] = {}
        off_chs_smo = off_ict_smo[filename]
        exp_ict_smo[filename] = {}
        exp_chs_smo = exp_ict_smo[filename]
        indices = [ind for ind, x in enumerate(osfilenames) if x == filename]

        result_dir_tmp = os.path.join(result_dir_case_ict, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        if len(indices) > 0:

            print('%d seizures in the file %s' % (len(indices), filename))
            for i in range(len(indices)):
                st = szstart[indices[i]]
                sp = szstop[indices[i]]
                print('************Internal************', sp-st)
                # if sp - st < 30:
                sp = st
                st = st - 1200
                data_ict[filename] = np.array(tmp[:, st * sampRate:sp * sampRate])
                nCHs = data_ict[filename].shape[0]
                for j in range(nCHs):
                    with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                              newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['offset', 'exponent', 'class'])
                    chData_ict = data_ict[filename][j, :]
                    nseg_ict = int(np.floor(len(chData_ict) / segLen))
                    print('Now is the channel %d,nseg_ict:%d' % (j, nseg_ict))
                    segData_ict = []
                    for n in range(0, nseg_ict):
                        segData_ict.append(chData_ict[n * segLen:(n + 1) * segLen])
                    segData_ict = np.array(segData_ict)
                    print("seizure %d shape of segData_ict (%d,%d)" % (i, segData_ict.shape[0], segData_ict.shape[1]))
                    off_ict_chs = []
                    exp_ict_chs = []
                    for k in range(segData_ict.shape[0]):
                        seg_ict = segData_ict[k, :]
                        f_ict, pww_ict = signal.welch(seg_ict, fs=sampRate, noverlap=128, nfft=512)
                        plt_log = False
                        fm_ict = FOOOF(peak_width_limits=[1, 8],
                                       max_n_peaks=6, min_peak_height=0.15, aperiodic_mode='knee')
                        fm_ict.fit(f_ict, pww_ict, [0.5, 30])
                        if type(fm_ict.get_params('aperiodic_params')) is np.ndarray:
                            off_ict_temp = fm_ict.get_params('aperiodic_params')[0]
                            exp_ict_temp = fm_ict.get_params('aperiodic_params')[2]
                            off_ict_chs.append(fm_ict.get_params('aperiodic_params')[0])
                            exp_ict_chs.append(fm_ict.get_params('aperiodic_params')[2])
                            with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                      newline='') as csvfile:
                                writer = csv.writer(csvfile)
                                writer.writerow([off_ict_temp, exp_ict_temp, 0])
                        else:
                            off_ict_chs.append(0)
                            exp_ict_chs.append(0)
                    off_chs['chs' + str(j + 1)] = off_ict_chs
                    exp_chs['chs' + str(j + 1)] = exp_ict_chs
    split_n = 3
    for filename in filesnames_int:
        print('Now doing the interictal files...')
        rawEEG = read_raw_edf('%s/%s' % (dir, filename), verbose=0, preload=True)
        rawEEG.pick_channels(chs)
        tmp = rawEEG.to_data_frame()
        tmp = tmp.values[:, 1:]
        # tmp = np.matrix(tmp)
        tmp = tmp.T
        data_int[filename] = tmp
        assert tmp.shape[0] == len(chs)
        print('=========================================')
        print('The interictal-file channels number is alright: 21')
        print('=========================================')

        # n_ratio = divmod(len(label_int),len(label_ict))[0]

        off_int[filename] = {}
        off_chs = off_int[filename]
        exp_int[filename] = {}
        exp_chs = exp_int[filename]
        off_int_smo[filename] = {}
        off_chs_smo = off_int_smo[filename]
        exp_int_smo[filename] = {}
        exp_chs_smo = exp_int_smo[filename]
        nCHs = data_int[filename].shape[0]

        result_dir_tmp = os.path.join(result_dir_case_int, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        for j in range(0, nCHs):
            with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                      newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['offset', 'exponent', 'class'])
            chData_int = data_int[filename][j, :]
            nseg_int = int(np.floor(len(chData_int) / segLen))
            segData_int = []
            for n in range(0, nseg_int):
                segData_int.append(chData_int[n * segLen:(n + 1) * segLen])
            list_length = len(segData_int)
            num_samples = divmod(list_length, split_n)[0]
            random.seed(44)
            random_int = random.randint(0, 2)
            if random_int < 2:
                segData_int = segData_int[random_int * num_samples:(random_int + 1) * num_samples]
            else:
                segData_int = segData_int[random_int * num_samples:]
            segData_int = np.array(segData_int)

            off_int_chs = []
            exp_int_chs = []
            for k in range(segData_int.shape[0]):
                seg_int = segData_int[k, :]
                f_int, pww_int = signal.welch(seg_int, fs=sampRate, noverlap=128, nfft=512)
                plt_log = False
                fm_int = FOOOF(peak_width_limits=[1, 8],
                               max_n_peaks=6, min_peak_height=0.15, aperiodic_mode='knee')
                fm_int.fit(f_int, pww_int, [0.5, 30])
                off_int_temp = fm_int.get_params('aperiodic_params')[0]
                exp_int_temp = fm_int.get_params('aperiodic_params')[2]
                off_int_chs.append(fm_int.get_params('aperiodic_params')[0])
                exp_int_chs.append(fm_int.get_params('aperiodic_params')[2])
                with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                          newline='') as csvfile:
                    writer = csv.writer(csvfile)
                    writer.writerow([off_int_temp, exp_int_temp, 1])
            off_chs['chs' + str(j + 1)] = off_int_chs
            exp_chs['chs' + str(j + 1)] = exp_int_chs

    p_off = {}
    p_exp = {}

    for filename in filesnames_ict:

        with open(result_dir_aperi + '/%s.csv' % (filename), 'a+', encoding='utf-8', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['channel', 'p_off_avg', 'p_exp_avg'])

        off_ict_file = off_ict[filename]
        exp_ict_file = exp_ict[filename]
        p_off[filename] = {}
        p_exp[filename] = {}
        p_chs_off = p_off[filename]
        p_chs_exp = p_exp[filename]

        p_chs_off_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filesnames_int))]
        p_chs_off_tem = np.array(p_chs_off_tem)
        p_chs_exp_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filesnames_int))]
        p_chs_exp_tem = np.array(p_chs_exp_tem)
        for i in range(0, nCHs):
            print('now is doing the channel %d ' % i)
            off_chs_ict = off_ict_file['chs' + str(i + 1)]
            exp_chs_ict = exp_ict_file['chs' + str(i + 1)]
            for j in range(len(filesnames_int)):
                off_chs_int = off_int[filesnames_int[j]]['chs' + str(i + 1)]
                exp_chs_int = exp_int[filesnames_int[j]]['chs' + str(i + 1)]
                p_off_tmp = ttest_for_p_value(off_chs_ict, off_chs_int)
                p_exp_tmp = ttest_for_p_value(exp_chs_ict, exp_chs_int)
                p_chs_off_tem[j][i] = p_off_tmp
                p_chs_exp_tem[j][i] = p_exp_tmp
            p_off_avg = np.mean(p_chs_off_tem[:, i])
            p_exp_avg = np.mean(p_chs_exp_tem[:, i])
            p_chs_off['chs' + str(i + 1)] = p_off_avg
            p_chs_exp['chs' + str(i + 1)] = p_exp_avg
            with open(result_dir_aperi + '/%s.csv' % (filename), 'a+', encoding='utf-8', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['chs' + str(i + 1), p_off_avg, p_exp_avg])

        print('The channel significance order of %s was as list.' % (filename))
        p_off_order = sorted(p_chs_off.items(), key=lambda x: x[1], reverse=False)
        print(p_off_order)
        p_exp_order = sorted(p_chs_exp.items(), key=lambda x: x[1], reverse=False)
        print(p_exp_order)
        print('The inference statistics of %s have been all finished.' % (filename))

print('The inference statistics have been all finished.')
# ###*****开始逐通道的循环*******###
# off_chs = {}
# exp_chs = {}
# off_chs_smo = {}
# exp_chs_smo = {}
# nCHs = tmp.shape[1]  ##22
# for i in range (0,nCHs):
#     segData_ict = [ ]
#     sampRate = 256
#     chData = data[i]  

#     ########发作文件只有一个发作时的数据截取###########
#     chData_ict = chData[st*sampRate:sp*sampRate]
#     chData_int1 = chData[0:(st-1)*sampRate]
#     chData_int2 = chData[(sp+1)*sampRate:len(chData)]
#     chData_int = np.concatenate((chData_int1,chData_int2)) #其实没有用上

#     segLen = sampRate * len_t
#     #######发作期分段###########
#     nseg_ict = int(np.floor(len(chData_ict)/segLen))  ####单个发作文件不是这么写的
#     print('nseg_int',nseg_ict) 
#     for j in range(0,nseg_ict):
#         segData_ict.append(chData_ict[j*segLen:(j+1)*segLen]) 
#     segData_ict = np.array(segData_ict)
#     print("the shape of segData_ict:",segData_ict.shape)  ##(8,1280)

#     #######发作间期分段###########
#     segData_int = [ ]
#     nseg_int = int(np.floor(len(chData_int)/segLen))
#     print('nseg_int',nseg_int) 
#     for k in range(0,nseg_int):
#         segData_int.append(chData_int[k*segLen:(k+1)*segLen])
#     segData_int = np.array(segData_int)
#     print("the shape of segData_int:",segData_int.shape)


#     ########################保存ictal结果文件为csv格式########################################
#     with open('/home/hanyaning/ljh/fooof-main/statistics_result/ictal/aperiodic_ch[%d].csv'%(i+1),'a+', encoding='utf-8', newline='') as csvfile:
#         writer = csv.writer(csvfile)
#         writer.writerow(['offset','exponent','class'])

#  ######开始进行fooof模拟#########
#     off_ict = []
#     exp_ict = []
#     ####首先fit ictal数据#####
#     for n in range(segData_ict.shape[0]):
#         data_ict = segData_ict[n,:]
#         times = np.arange(0,5,1/sampRate)
#         f_ict,pww_ict = signal.welch(data_ict,fs=sampRate,noverlap=128,nfft=512)
#         plt_log = False
#         #fm_ict = FOOOF(peak_width_limits=[1, 8], max_n_peaks=6, min_peak_height=0.15,aperiodic_mode='knee')
#         fm_ict = FOOOF(peak_width_limits=[1, 8], max_n_peaks=6, min_peak_height=0.15,aperiodic_mode='knee')
#         fm_ict.fit(f_ict, pww_ict, [0.5, 30])
#         off_ict_temp = fm_ict.get_params('aperiodic_params')[0]
#         exp_ict_temp = fm_ict.get_params('aperiodic_params')[2]
#         off_ict.append(fm_ict.get_params('aperiodic_params')[0])
#         exp_ict.append(fm_ict.get_params('aperiodic_params')[2])

#         with open('/home/hanyaning/ljh/fooof-main/statistics_result/ictal/aperiodic_ch[%d].csv'%(i+1),'a+', encoding='utf-8', newline='') as csvfile:
#             writer = csv.writer(csvfile)
#             writer.writerow([off_ict_temp,exp_ict_temp,0])
#             # writer.writerow(fm_ict.get_params('aperiodic_params'))


#     ########################保存interictal结果文件为csv格式########################################
#     with open('/home/hanyaning/ljh/fooof-main/statistics_result/interictal/aperiodic_ch[%d].csv'%(i+1),'a+', encoding='utf-8', newline='') as csvfile:
#         writer = csv.writer(csvfile)
#         writer.writerow(['offset','exponent','class'])

#     ####首先fit interictal数据#####
#     off_int = []
#     exp_int = []
#     for m in range(segData_int.shape[0]):
#         data_int = segData_int[m,:]
#         times = np.arange(0,5,1/sampRate)
#         f_int,pww_int = signal.welch(data_int,fs=sampRate,noverlap=128,nfft=512)
#         plt_log = False
#         #fm_int = FOOOF(peak_width_limits=[1, 8], max_n_peaks=6, min_peak_height=0.15,aperiodic_mode='knee')
#         fm_int = FOOOF(peak_width_limits=[1, 8], max_n_peaks=6, min_peak_height=0.15,aperiodic_mode='knee')
#         fm_int.fit(f_int, pww_int, [0.5, 30])
#         off_int_temp = fm_int.get_params('aperiodic_params')[0]
#         exp_int_temp = fm_int.get_params('aperiodic_params')[2]
#         off_int.append(fm_int.get_params('aperiodic_params')[0])
#         exp_int.append(fm_int.get_params('aperiodic_params')[2])

#         with open('/home/hanyaning/ljh/fooof-main/statistics_result/interictal/aperiodic_ch[%d].csv'%(i+1),'a+', encoding='utf-8', newline='') as csvfile:
#             writer = csv.writer(csvfile)
#             writer.writerow([off_int_temp,exp_int_temp,1])

#     ######对offset进行双样本检验####       
#     p_std_off = stats.levene(off_ict,off_int)  
#     ###当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性。
#     if p_std_off[1] > 0.05:
#         p_ttest_off = stats.ttest_ind(off_ict,off_int)
#     else:
#         p_ttest_off = stats.ttest_ind(off_ict,off_int,equal_var=False)
#     off_chs['ch%d'%(i+1)] = p_ttest_off[1]
#     ######对exponent进行双样本检验####
#     p_std_exp = stats.levene(exp_ict,exp_int)  
#     ###当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性
#     if p_std_exp[1] > 0.05:
#         p_ttest_exp = stats.ttest_ind(exp_ict,exp_int)
#     else:
#         p_ttest_exp = stats.ttest_ind(exp_ict,exp_int,equal_var=False)
#     exp_chs['ch%d'%(i+1)] = p_ttest_exp[1]  

#     #####做smote以后看看会不会提升显著性###
#     off_ict = np.array(off_ict).reshape((len(off_ict),1))
#     exp_ict = np.array(exp_ict).reshape((len(exp_ict),1))
#     aperi_ict_ori = np.concatenate((off_ict,exp_ict),axis=1)
#     label_ict = [0]*aperi_ict_ori.shape[0]
#     # label_ict = np.zeros((aperi_ict_ori.shape[0],1))
#     off_int = np.array(off_int).reshape((len(off_int),1))
#     exp_int = np.array(exp_int).reshape((len(exp_int),1))
#     aperi_int_ori = np.concatenate((off_int,exp_int),axis=1)
#     label_int = [1]*aperi_int_ori.shape[0] 

#     ##构建smote数据集###
#     aperi_ori = np.concatenate((aperi_ict_ori,aperi_int_ori),axis=0)
#     label_ori = np.concatenate((label_ict,label_int))
#     ###确定数据扩充比例###
#     k_neighbors = 5
#     n_samples_minor = len(label_ict)
#     n_ratio = divmod(len(label_int),len(label_ict))[0]
#     if n_ratio>=k_neighbors:
#         smo = SMOTE(random_state=42,sampling_strategy={0:n_samples_minor*k_neighbors})
#     else:
#         smo = SMOTE(random_state=42,sampling_strategy={0:n_samples_minor*n_ratio})
#     aperi_smo,label_smo = smo.fit_resample(aperi_ori,label_ori)
#     print('the ratio of two classes before smote:',Counter(label_ori)) #check the ratio after smote
#     print('the ratio of two classes after smote:',Counter(label_smo)) #check the ratio after smote
#     index_label_ict_smo = np.where(label_smo==0)
#     index_label_int_smo = np.where(label_smo==1)
#     aperi_ict_smo = aperi_smo[index_label_ict_smo][:]
#     off_ict_smo = aperi_ict_smo[:,0]
#     exp_ict_smo = aperi_ict_smo[:,1]
#     aperi_int_smo = aperi_smo[index_label_int_smo][:]
#     off_int_smo = aperi_int_smo[:,0]
#     exp_int_smo = aperi_int_smo[:,1]
#     off_chs_smo['ch%d'%(i+1)] = ttest_for_p_value(off_ict_smo,off_int_smo)
#     exp_chs_smo['ch%d'%(i+1)] = ttest_for_p_value(exp_ict_smo,exp_int_smo)

# off_order = sorted(off_chs.items(),key=lambda x:x[1], reverse=False)
# print('the offset rank before smote:',off_order)
# exp_order = sorted(exp_chs.items(),key=lambda x:x[1], reverse=False)
# print('the exponent rank before smote:',exp_order)

# off_smo_order = sorted(off_chs_smo.items(),key=lambda x:x[1], reverse=False)
# print('the offset rank after smote:',off_smo_order)
# exp_smo_order = sorted(exp_chs_smo.items(),key=lambda x:x[1], reverse=False)
# print('the exponent rank after smote:',exp_smo_order)
