import matplotlib.pyplot as plt
from fooof import FOOOF
from fooof.sim.gen import gen_aperiodic
from fooof.plts.spectra import plot_spectra
from fooof.plts.annotate import plot_annotated_peak_search
import os
import pandas as pd
import mne
import matplotlib.pyplot as plt
##from scipy import signal,fft
import numpy as np
from mne.io import RawArray, read_raw_edf
# from mne.channels import read_montage
from mne import create_info, concatenate_raws, pick_types
from mne.filter import notch_filter
from scipy import signal, stats
import csv
from collections import Counter
from imblearn.over_sampling import SMOTE
import random
import pdb


def loren_aperiodic_fit(b, freqs, exp, k=0):
    loren_ap = b - np.log10(k + freqs ** exp)
    return loren_ap


def ttest_for_p_value(cls_a, cls_b):
    # 当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性。
    p_std = stats.levene(cls_a, cls_b)
    if p_std[1] > 0.05:
        p_ttest = stats.ttest_ind(cls_a, cls_b)
    else:
        p_ttest = stats.ttest_ind(cls_a, cls_b, equal_var=False)
    p_value = p_ttest[1]
    return p_value


data_dir = r'E:\pythonProject\Seizure_forecasting\mnt\data4\datasets\seizure\CHB-MIT'
result_dir = r'E:\pythonProject\Seizure_forecasting\fooof-main-new\statistics_result_tpw'  # 参数的特征值
if os.path.isdir(result_dir):
    pass
else:
    os.makedirs(result_dir)
onset = pd.read_csv(os.path.join(data_dir, 'seizure_summary.csv'), header=0)
# 使用case 1的03, 04, 15, 18，26这5个edf，因为16和21的前期数据太短
# osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']
osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']
osfilenames = list(osfilenames)

segment = pd.read_csv(os.path.join(data_dir, 'segmentation.csv'), header=None)
nsfilenames = list(segment[segment[1] == 0][0])

sampRate = 256
len_t = 5
segLen = sampRate * len_t

# case_files = [f for f in os.listdir(data_dir) if f.startswith('chb')]
# case_files = ['chb02', 'chb03', 'chb10', 'chb14', 'chb16', 'chb18']
# case_files = ['chb03', 'chb10', 'chb14', 'chb16', 'chb18']
case_files = ['chb02']

for tempcase in case_files:

    char_to_remove = 'chb'
    target = tempcase.replace(char_to_remove, '')

    if target in ['13', '16']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0', u'FZ-CZ', u'CZ-PZ']

    elif target in ['04']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'P8-O2',
               u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT10-T8']

    elif target in ['09']:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'P8-O2',
               u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT9-FT10', u'FT10-T8']

    else:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3',
               u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0',
               u'P8-O2', u'FZ-CZ', u'CZ-PZ', u'T7-FT9', u'FT9-FT10', u'FT10-T8']

    # nCHs = len(chs)
    dir = os.path.join(data_dir, tempcase)

    result_dir_case_ict = os.path.join(result_dir, 'ictal', tempcase)
    if not os.path.exists(result_dir_case_ict):
        os.makedirs(result_dir_case_ict)
        print("case Folder for result created successfully!")
    else:
        print("case Folder for result already exists!")

    result_dir_case_int = os.path.join(result_dir, 'interictal', tempcase)
    if not os.path.exists(result_dir_case_int):
        os.makedirs(result_dir_case_int)
        print("case Folder for result created successfully!")
    else:
        print("case Folder for result already exists!")

    result_dir_tpw = os.path.join(result_dir, 'tpw', tempcase)
    if not os.path.exists(result_dir_tpw):
        os.makedirs(result_dir_tpw)
        print("TPW component Folder for result created successfully!")
    else:
        print("TPW component Folder for result already exists!")

    text_files = [f for f in os.listdir(dir) if f.endswith('.edf')]

    filesnames_ict = [filename for filename in text_files if filename in osfilenames]
    filesnames_int = [filename for filename in text_files if filename in nsfilenames]

    data_ict = {}
    tpw1_ict = {}
    tpw2_ict = {}
    data_int = {}
    tpw1_int = {}
    tpw2_int = {}

    totalfiles = len(filesnames_ict)
    print('case %s Total ictal files %d' % (tempcase, totalfiles))

    for filename in filesnames_ict:
        rawEEG = read_raw_edf('%s/%s' % (dir, filename), verbose=0, preload=True)
        # preload如果为True，则数据将被预加载到内存中
        # pdb.set_trace()
        rawEEG.pick_channels(chs)
        tmp = rawEEG.to_data_frame()
        tmp = tmp.values[:, 1:]
        tmp = tmp.T
        assert tmp.shape[0] == len(chs)
        print('=========================================')
        print('The ictal-file channels number is alright: 21')
        print('=========================================')

        tpw1_ict[filename] = {}
        tpw1_chs = tpw1_ict[filename]
        tpw2_ict[filename] = {}
        tpw2_chs = tpw2_ict[filename]
        indices = [ind for ind, x in enumerate(osfilenames) if x == filename]

        result_dir_tmp = os.path.join(result_dir_case_ict, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        if len(indices) > 0:
            print('%d seizures in the file %s' % (len(indices), filename))
            for i in range(len(indices)):
                st = szstart[indices[i]]
                sp = szstop[indices[i]]
                # if sp - st < 30:
                # st = st - 300  # 相当取的数据是all ictal + 5min pre-ictal
                sp = st
                st = st - 1200
                data_ict[filename] = np.array(tmp[:, st * sampRate:sp * sampRate])
                nCHs = data_ict[filename].shape[0]
                for j in range(nCHs):
                    with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                              newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['tpw1', 'tpw2', 'class'])
                    chData_ict = data_ict[filename][j, :]
                    nseg_ict = int(np.floor(len(chData_ict) / segLen))
                    print('Now is the channel %d,nseg_ict:%d' % (j, nseg_ict))
                    segData_ict = []
                    for n in range(0, nseg_ict):
                        segData_ict.append(chData_ict[n * segLen:(n + 1) * segLen])
                    segData_ict = np.array(segData_ict)
                    print("seizure %d shape of segData_ict (%d,%d)" % (i, segData_ict.shape[0], segData_ict.shape[1]))
                    tpw1_ict_chs = []
                    tpw2_ict_chs = []
                    for k in range(segData_ict.shape[0]):
                        seg_ict = segData_ict[k, :]
                        f_ict, pww_ict = signal.welch(seg_ict, fs=sampRate, noverlap=128, nfft=512)
                        plt_log = False
                        fm_ict = FOOOF(peak_width_limits=[1, 8],
                                       max_n_peaks=6, min_peak_height=0.15)
                        fm_ict.fit(f_ict, pww_ict, [0.5, 30])
                        cf_fit_ict = []
                        pw_fit_ict = []
                        gua_params_ict = fm_ict.get_params('peak_params')
                        [off_ict, exp_ict] = fm_ict.get_params('aperiodic_params')
                        pw_min = loren_aperiodic_fit(off_ict, 30, exp_ict)
                        if type(gua_params_ict[0]) is np.ndarray and len(gua_params_ict) == 1:
                            cf_max_ict = gua_params_ict[0][0]
                            pw_max_ict = gua_params_ict[0][1]
                            pw_2max_ict = 0
                            cf_2max_ict = 0
                            pw_max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw1_ict_tmp = pw_max_ict + (pw_max_ap - pw_min)
                            tpw2_ict_tmp = 0
                        elif type(gua_params_ict[0]) is np.ndarray and len(gua_params_ict) >= 2:
                            for t in range(len(gua_params_ict)):
                                cf_fit_ict.append(gua_params_ict[t][0])
                                pw_fit_ict.append(gua_params_ict[t][1])
                            pw_maxindex_ict = pw_fit_ict.index(max(pw_fit_ict))
                            pw_max_ict = max(pw_fit_ict)
                            cf_max_ict = cf_fit_ict[pw_maxindex_ict]
                            pw_max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw1_ict_tmp = pw_max_ict + (pw_max_ap - pw_min)
                            pw_fit_ict[pw_maxindex_ict] = float("-inf")
                            pw_2maxindex_ict = pw_fit_ict.index(max(pw_fit_ict))
                            pw_2max_ict = max(pw_fit_ict)
                            cf_2max_ict = cf_fit_ict[pw_2maxindex_ict]
                            pw_2max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw2_ict_tmp = pw_2max_ict + (pw_2max_ap - pw_min)
                        else:
                            tpw1_ict_tmp = 0
                            cf_max_ict = 0
                            tpw2_ict_tmp = 0
                            cf_2max_ict = 0
                        tpw1_ict_chs.append(tpw1_ict_tmp)
                        tpw2_ict_chs.append(tpw2_ict_tmp)
                        with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                  newline='') as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow([tpw1_ict_tmp, tpw2_ict_tmp, 0])
                    tpw1_chs['chs' + str(j + 1)] = tpw1_ict_chs
                    tpw2_chs['chs' + str(j + 1)] = tpw2_ict_chs

    split_n = 3
    for filename in filesnames_int:
        print('Now doing the interictal files...')
        rawEEG = read_raw_edf('%s/%s' % (dir, filename), verbose=0, preload=True)
        rawEEG.pick_channels(chs)
        tmp = rawEEG.to_data_frame()
        tmp = tmp.values[:, 1:]
        # tmp = np.matrix(tmp)
        tmp = tmp.T
        assert tmp.shape[0] == len(chs)
        print('=========================================')
        print('The interictal-file channels number is alright: 21')
        print('=========================================')

        data_int[filename] = tmp

        tpw1_int[filename] = {}
        tpw1_chs = tpw1_int[filename]
        tpw2_int[filename] = {}
        tpw2_chs = tpw2_int[filename]
        nCHs = data_int[filename].shape[0]

        result_dir_tmp = os.path.join(result_dir_case_int, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        for j in range(0, nCHs):
            with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['tpw1', 'tpw2', 'class'])
            chData_int = data_int[filename][j, :]
            nseg_int = int(np.floor(len(chData_int) / segLen))
            segData_int = []
            for n in range(0, nseg_int):
                segData_int.append(chData_int[n * segLen:(n + 1) * segLen])
            list_length = len(segData_int)
            num_samples = divmod(list_length, split_n)[0]
            random.seed(44)
            random_int = random.randint(0, 2)
            if random_int < 2:
                segData_int = segData_int[random_int * num_samples:(random_int + 1) * num_samples]
            else:
                segData_int = segData_int[random_int * num_samples:]
            segData_int = np.array(segData_int)

            tpw1_int_chs = []
            tpw2_int_chs = []
            cf_fit_int = []
            pw_fit_int = []
            for k in range(segData_int.shape[0]):
                seg_int = segData_int[k, :]
                f_int, pww_int = signal.welch(seg_int, fs=sampRate, noverlap=128, nfft=512)
                plt_log = False
                fm_int = FOOOF(peak_width_limits=[1, 8],
                               max_n_peaks=6, min_peak_height=0.15)
                fm_int.fit(f_int, pww_int, [0.5, 30])
                gua_params_int = fm_int.get_params('peak_params')
                [off_int, exp_int] = fm_int.get_params('aperiodic_params')
                pw_min = loren_aperiodic_fit(off_int, 30, exp_int)
                if type(gua_params_int[0]) is np.ndarray and len(gua_params_int) == 1:
                    cf_max_int = gua_params_int[0][0]
                    pw_max_int = gua_params_int[0][1]
                    pw_2max_int = 0
                    cf_2max_int = 0
                    w_max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                    tpw1_int_tmp = pw_max_int + (pw_max_ap - pw_min)
                    tpw2_int_tmp = 0
                elif type(gua_params_int[0]) is np.ndarray and len(gua_params_int) >= 2:
                    for t in range(len(gua_params_int)):
                        cf_fit_int.append(gua_params_int[t][0])
                        pw_fit_int.append(gua_params_int[t][1])
                    pw_maxindex_int = pw_fit_int.index(max(pw_fit_int))
                    pw_max_int = max(pw_fit_int)
                    cf_max_int = cf_fit_int[pw_maxindex_int]
                    pw_max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                    tpw1_int_tmp = pw_max_int + (pw_max_ap - pw_min)
                    pw_fit_int[pw_maxindex_int] = float("-inf")
                    pw_2maxindex_int = pw_fit_int.index(max(pw_fit_int))
                    pw_2max_int = max(pw_fit_int)
                    cf_2max_int = cf_fit_int[pw_2maxindex_int]
                    pw_2max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                    tpw2_int_tmp = pw_2max_int + (pw_2max_ap - pw_min)
                else:
                    tpw1_int_tmp = 0
                    cf_max_int = 0
                    tpw2_int_tmp = 0
                    cf_2max_int = 0
                tpw1_int_chs.append(tpw1_int_tmp)
                tpw2_int_chs.append(tpw2_int_tmp)
                with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8', newline='') as csvfile:
                    writer = csv.writer(csvfile)
                    writer.writerow([tpw1_int_tmp, tpw2_int_tmp, 1])
            tpw1_chs['chs' + str(j + 1)] = tpw1_int_chs
            tpw2_chs['chs' + str(j + 1)] = tpw2_int_chs

    p_tpw1 = {}
    p_tpw2 = {}

    for filename in filesnames_ict:

        with open(result_dir_tpw + '/%s.csv' % (filename), 'a+', encoding='utf-8', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['channel', 'p_tpw1_avg', 'p_tpw2_avg'])

        tpw1_ict_file = tpw1_ict[filename]
        tpw2_ict_file = tpw2_ict[filename]
        p_tpw1[filename] = {}
        p_tpw2[filename] = {}
        p_chs_tpw1 = p_tpw1[filename]
        p_chs_tpw2 = p_tpw2[filename]
        # nCHs = 21
        p_chs_tpw1_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filesnames_int))]
        p_chs_tpw1_tem = np.array(p_chs_tpw1_tem)
        p_chs_tpw2_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filesnames_int))]
        p_chs_tpw2_tem = np.array(p_chs_tpw2_tem)
        for i in range(0, nCHs):
            print('now is doing the channel %d ' % i)
            tpw1_chs_ict = tpw1_ict_file['chs' + str(i + 1)]
            tpw2_chs_ict = tpw2_ict_file['chs' + str(i + 1)]
            for j in range(len(filesnames_int)):
                tpw1_chs_int = tpw1_int[filesnames_int[j]]['chs' + str(i + 1)]
                tpw2_chs_int = tpw1_int[filesnames_int[j]]['chs' + str(i + 1)]
                p_tpw1_tmp = ttest_for_p_value(tpw1_chs_ict, tpw1_chs_int)
                p_tpw2_tmp = ttest_for_p_value(tpw2_chs_ict, tpw2_chs_int)
                p_chs_tpw1_tem[j][i] = p_tpw1_tmp
                p_chs_tpw2_tem[j][i] = p_tpw2_tmp
            p_tpw1_avg = np.mean(p_chs_tpw1_tem[:, i])
            p_tpw2_avg = np.mean(p_chs_tpw2_tem[:, i])
            p_chs_tpw1['chs' + str(i + 1)] = p_tpw1_avg
            p_chs_tpw2['chs' + str(i + 1)] = p_tpw2_avg
            with open(result_dir_tpw + '/%s.csv' % (filename), 'a+', encoding='utf-8', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['chs' + str(i + 1), p_tpw1_avg, p_tpw2_avg])

        print('The channel significance order of %s was as list.' % (filename))
        p_tpw1_order = sorted(p_chs_tpw1.items(), key=lambda x: x[1], reverse=False)
        print(p_tpw1_order)
        p_tpw2_order = sorted(p_chs_tpw2.items(), key=lambda x: x[1], reverse=False)
        print(p_tpw2_order)
        print('The inference statistics of %s have been all finished.' % (filename))

print('The inference statistics have been all finished.')
