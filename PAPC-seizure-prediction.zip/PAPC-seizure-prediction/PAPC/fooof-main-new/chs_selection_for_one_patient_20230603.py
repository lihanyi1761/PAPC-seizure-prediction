import os
import numpy as np
import pandas as pd
from collections import Counter

chs_dir = 'E:/pythonProject/Seizure_forecasting/fooof-main-new/rank_chs'
save_dir = 'E:/pythonProject/Seizure_forecasting/fooof-main-new/rank_chs_one_patient'
if os.path.exists(save_dir):
    pass
else:
    os.makedirs(save_dir)

# subjectName = [f for f in os.listdir(chs_dir) if f.endswith('.csv')]  # ['chb05.csv', 'chb16.csv']每一列对应了一个发作文件的通道排序
case_files = 'chb03'
subjectName = case_files + '.csv'
subjectName = [subjectName]

chs_rank = {}


def get_key2(dct, value):
    return [k for (k, v) in dct.items() if v == value]


for subjecti in subjectName:
    # chscsvtPathName = chs_dir + subjecti
    chscsvtPathName = os.path.join(chs_dir, subjecti)
    chs_rank_final_PathName = os.path.join(save_dir, subjecti)
    # chs_rank_final_PathName = save_dir + subjecti
    df = pd.read_csv(chscsvtPathName)
    df_szfile = list(df.keys())
    df_chs_rank = df.values

    array_to_list = []
    for i in range(df_chs_rank.shape[1]):
        print(i)
        array_to_list_tmp = df_chs_rank[:, i].tolist()
        array_to_list += array_to_list_tmp
    array_to_find_same_chs = dict(Counter(array_to_list))
    print({key: value for key, value in array_to_find_same_chs.items() if value > 1})  # #展现重复元素和重复次数
    chs_num = 0
    chs_rank_final = []
    for k in range(len(df_szfile), -1, -1):
        chs_rank_score = {}
        chs_num_temp = 0
        chs_rank_temp = get_key2(array_to_find_same_chs, k)
        for chsi in chs_rank_temp:
            df_chs_rank_index = np.array(np.where(df_chs_rank == chsi))
            df_chs_rank_temp = df_chs_rank_index[0]
            chs_rank_score[chsi] = df_chs_rank_temp.sum()
            chs_num_temp += 1
        if chs_num_temp == len(chs_rank_temp):
            chs_order = sorted(chs_rank_score.items(), key=lambda x: x[1], reverse=False)
            for chs_score in chs_order:
                chs_rank_final.append(chs_score[0])
        chs_num += chs_num_temp
        if chs_num > 16:
            chs_rank_final = chs_rank_final[:16]
            break
    df_sum = pd.DataFrame({subjecti: chs_rank_final})
    df_sum.to_csv(chs_rank_final_PathName, index=0)
