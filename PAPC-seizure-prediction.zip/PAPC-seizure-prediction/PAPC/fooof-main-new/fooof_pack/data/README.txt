Data
====

Example data files for the FOOOF module.