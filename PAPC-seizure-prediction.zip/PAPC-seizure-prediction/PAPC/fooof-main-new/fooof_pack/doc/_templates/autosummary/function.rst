{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autofunction:: {{ objname }}

.. include:: {{fullname}}.examples

.. raw:: html

    <div style='clear:both'></div>
