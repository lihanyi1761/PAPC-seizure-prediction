{{ fullname | escape | underline}}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
    :no-inherited-members:

.. include:: {{ fullname }}.examples
