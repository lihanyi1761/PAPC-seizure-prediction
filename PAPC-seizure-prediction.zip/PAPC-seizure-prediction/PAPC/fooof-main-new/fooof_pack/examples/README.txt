.. _examples:

Examples
========

This section has examples of different functionality available in the module. 

Examples are organized by topic, and can be explored in any order.

.. contents:: Contents
   :local:
   :depth: 3


