Analyses
--------

Example analyses involving parameterizing neural power spectra.