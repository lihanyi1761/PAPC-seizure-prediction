Managing Objects
----------------

Examples of how to use, organize, work with, and check FOOOF objects.