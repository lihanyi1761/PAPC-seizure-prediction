Plotting
--------

Examples demonstrating the plot functions.