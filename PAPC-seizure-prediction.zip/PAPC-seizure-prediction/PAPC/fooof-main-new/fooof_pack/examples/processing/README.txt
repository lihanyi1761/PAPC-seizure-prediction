Processing
----------

Examples on how to process data related to spectral parameterization.