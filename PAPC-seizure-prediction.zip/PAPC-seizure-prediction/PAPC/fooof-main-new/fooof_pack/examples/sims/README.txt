Simulations
-----------

Examples covering simulating neural power spectra.