"""FOOOF - Fitting Oscillations & One-Over F"""

from .version import __version__

from .bands import Bands
from .objs import FOOOF, FOOOFGroup
from .objs.utils import fit_fooof_3d
