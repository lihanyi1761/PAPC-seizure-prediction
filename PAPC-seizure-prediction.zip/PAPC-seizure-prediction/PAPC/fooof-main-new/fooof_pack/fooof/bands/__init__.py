"""Bands sub-module for FOOOF."""

from .bands import Bands
