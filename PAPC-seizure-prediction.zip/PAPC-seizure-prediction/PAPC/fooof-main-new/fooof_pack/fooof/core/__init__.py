"""Sub-module for core functions for FOOOF."""
