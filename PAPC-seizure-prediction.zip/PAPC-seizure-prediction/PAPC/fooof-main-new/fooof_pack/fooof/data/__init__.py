"""Data sub-module for FOOOF."""

from .data import FOOOFSettings, FOOOFMetaData, FOOOFResults, SimParams
