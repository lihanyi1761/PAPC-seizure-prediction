"""Plots sub-module for FOOOF."""

from .spectra import plot_spectra
from .spectra import plot_spectra as plot_spectrum
