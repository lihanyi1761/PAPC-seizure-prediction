"""Tests for FOOOF."""
