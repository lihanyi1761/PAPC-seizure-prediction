"""Utilities sub-module for FOOOF."""

from .data import trim_spectrum, interpolate_spectrum
