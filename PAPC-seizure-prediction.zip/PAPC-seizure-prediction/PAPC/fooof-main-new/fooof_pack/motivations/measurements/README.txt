Measurements
------------

This section compares how existing approaches relate and compare to parameterizing neural power spectra.

In particular, these examples investigate how various methods work in the context of conceptualize neural time series as a combination of periodic and aperiodic activity.