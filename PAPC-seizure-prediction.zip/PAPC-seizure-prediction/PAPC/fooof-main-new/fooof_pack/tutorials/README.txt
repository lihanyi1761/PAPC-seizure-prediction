.. _tutorials:

Tutorial
========

This section has the official tutorial, which introduces the module and demonstrates how to model power spectra.

This tutorial is designed to be worked through in order.

.. contents:: Contents
   :local:
   :depth: 3