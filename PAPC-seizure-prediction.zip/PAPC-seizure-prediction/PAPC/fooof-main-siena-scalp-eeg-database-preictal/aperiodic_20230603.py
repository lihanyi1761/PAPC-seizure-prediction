import matplotlib.pyplot as plt
from fooof import FOOOF
from fooof.sim.gen import gen_aperiodic
from fooof.plts.spectra import plot_spectra
from fooof.plts.annotate import plot_annotated_peak_search
import os
import pandas as pd
import mne
# import matplotlib.pyplot as plt 
##from scipy import signal,fft
import numpy as np
from mne.io import RawArray, read_raw_edf
# from mne.channels import read_montage
from mne import create_info, concatenate_raws, pick_types
from mne.filter import notch_filter
from scipy import signal, stats
import csv
from collections import Counter
from imblearn.over_sampling import SMOTE
import random


def ttest_for_p_value(cls_a, cls_b):
    # 当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性。
    p_std = stats.levene(cls_a, cls_b)
    if p_std[1] > 0.05:
        p_ttest = stats.ttest_ind(cls_a, cls_b)
    else:
        p_ttest = stats.ttest_ind(cls_a, cls_b, equal_var=False)
    p_value = p_ttest[1]
    return p_value


data_dir = r'E:\pythonProject\Seizure_forecasting\mnt\data4\datasets\seizure\siena-scalp-eeg-database-selected-9'
result_dir = r'E:\pythonProject\Seizure_forecasting\fooof-main-siena-scalp-eeg\statistics_result'  # 参数的特征值
if os.path.exists(result_dir):
    pass
else:
    os.makedirs(result_dir)

#############################每次只跑一例###################################
target = 'PN17'
#############################每次只跑一例###################################

sampRate = 512

len_t = 5
segLen = sampRate * len_t

ictal_list = pd.read_csv(os.path.join(data_dir, 'seizure_info_seconds.csv'))
dir = os.path.join(data_dir, target)  # 每一个target有多少文件
text_files = [f for f in os.listdir(dir) if f.endswith('.edf')]  # 加载数据
filenames = [filename for filename in text_files]
print('filenames: ', filenames)

if target in ['PN03', 'PN05', 'PN06', 'PN07', 'PN09', 'PN12', 'PN13']:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG Cz', 'EEG Pz', 'EEG FP2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # FP2导联是大写
elif target in ['PN16', 'PN17', 'PN14']:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG CZ', 'EEG Pz', 'EEG FP2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # FP2导联是大写 CZ也是大写
else:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG Cz', 'EEG Pz', 'EEG Fp2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # 29个通道，删去了两个EKG

result_dir_case_ict = os.path.join(result_dir, 'ictal', target)
if not os.path.exists(result_dir_case_ict):
    os.makedirs(result_dir_case_ict)
    print("case Folder for result created successfully!")
else:
    print("case Folder for result already exists!")

result_dir_case_int = os.path.join(result_dir, 'interictal', target)
if not os.path.exists(result_dir_case_int):
    os.makedirs(result_dir_case_int)
    print("case Folder for result created successfully!")
else:
    print("case Folder for result already exists!")

result_dir_aperi = os.path.join(result_dir, 'aperiodic', target)
if not os.path.exists(result_dir_aperi):
    os.makedirs(result_dir_aperi)
    print("Aperiodic component Folder for result created successfully!")
else:
    print("Aperiodic component Folder for result already exists!")

data_ict = {}
off_ict = {}
off_ict_smo = {}
exp_ict = {}
exp_ict_smo = {}
data_int = {}
off_int = {}
off_int_smo = {}
exp_int = {}
exp_int_smo = {}

for filename in filenames:
    edata_dir = os.path.join(dir, filename)
    rawEEG = read_raw_edf(edata_dir, verbose=0, preload=True)
    rawEEG.pick(chs)  # 选取通道
    tmp = rawEEG.to_data_frame()
    tmp = tmp.values
    print('##################', tmp.shape)
    tmp = tmp[:, 1:]
    print('##################', tmp.shape)
    print(tmp[:, 0])
    assert tmp.shape[1] == 29

    seizure_info = ictal_list[ictal_list['EDF Name'] == filename]
    szstart = seizure_info['Seizure Start Time']
    szstop = seizure_info['Seizure End Time']
    print('now process the file %s' % filename)
    print('the seizure start of this file', szstart)

    data_type = 'ictal'
    if data_type == 'ictal':
        SOP = 30 * 60 * sampRate  # origin = 30
        SPH = 5 * 60 * sampRate
        if tmp.shape[0] == len(chs):
            pass
        else:
            tmp = tmp.T
        off_ict[filename] = {}
        off_chs = off_ict[filename]
        exp_ict[filename] = {}
        exp_chs = exp_ict[filename]
        off_ict_smo[filename] = {}
        off_chs_smo = off_ict_smo[filename]
        exp_ict_smo[filename] = {}
        exp_chs_smo = exp_ict_smo[filename]

        result_dir_tmp = os.path.join(result_dir_case_ict, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        if len(szstart) > 0:
            print('%d seizures in the file %s' % (len(szstart), filename))
            for i in range(len(szstart)):
                st = szstart.iloc[i] * 512 - SPH  # e.g., SPH=5min  #发作前5min的时刻数据点
                sp = szstop.iloc[i] * 512  # 发作结束时刻数据点
                data_ict[filename] = np.array(tmp[:, st - SOP: st])  # 取发作前5min+SOP时间，至发作前5min

                nCHs = data_ict[filename].shape[0]
                for j in range(nCHs):
                    with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                              newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['offset', 'exponent', 'class'])
                    chData_ict = data_ict[filename][j, :]
                    nseg_ict = int(np.floor(len(chData_ict) / segLen))
                    print('Now is the channel %d,nseg_ict:%d' % (j, nseg_ict))
                    segData_ict = []
                    for n in range(0, nseg_ict):
                        segData_ict.append(chData_ict[n * segLen:(n + 1) * segLen])
                    segData_ict = np.array(segData_ict)
                    print("seizure %d shape of segData_ict (%d,%d)" % (i, segData_ict.shape[0], segData_ict.shape[1]))
                    off_ict_chs = []
                    exp_ict_chs = []
                    for k in range(segData_ict.shape[0]):
                        seg_ict = segData_ict[k, :]
                        f_ict, pww_ict = signal.welch(seg_ict, fs=sampRate, nperseg=2048, noverlap=1280, nfft=2560)
                        plt_log = False
                        fm_ict = FOOOF(peak_width_limits=[2, 12],
                                       max_n_peaks=6, min_peak_height=0.15, aperiodic_mode='knee')
                        fm_ict.fit(f_ict, pww_ict, [0.5, 30])  # 修改范围 fm_ict.fit(f_ict, pww_ict, [0.5, 30])
                        # if type(fm_ict.get_params('aperiodic_params')) is np.ndarray:
                        if fm_ict.has_model:  # 使用has_model属性来判断是否拟合成功
                            off_ict_temp = fm_ict.get_params('aperiodic_params')[0]
                            exp_ict_temp = fm_ict.get_params('aperiodic_params')[2]
                            off_ict_chs.append(fm_ict.get_params('aperiodic_params')[0])
                            exp_ict_chs.append(fm_ict.get_params('aperiodic_params')[2])
                            with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                      newline='') as csvfile:
                                writer = csv.writer(csvfile)
                                writer.writerow([off_ict_temp, exp_ict_temp, 0])
                        else:
                            # 调整数据的频率范围，去除过低或过高的频率
                            f_ict = f_ict[1:-1]
                            pww_ict = pww_ict[1:-1]
                            # 调整拟合设置或参数，增加最大峰值数量，降低最小峰值高度
                            fm_ict = FOOOF(peak_width_limits=[1, 8],
                                           max_n_peaks=10, min_peak_height=0.1, aperiodic_mode='knee')
                            fm_ict.fit(f_ict, pww_ict, [0.5, 30])
                            if fm_ict.has_model:
                                off_ict_temp = fm_ict.get_params('aperiodic_params')[0]
                                exp_ict_temp = fm_ict.get_params('aperiodic_params')[2]
                                off_ict_chs.append(fm_ict.get_params('aperiodic_params')[0])
                                exp_ict_chs.append(fm_ict.get_params('aperiodic_params')[2])
                                with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                          newline='') as csvfile:
                                    writer = csv.writer(csvfile)
                                    writer.writerow([off_ict_temp, exp_ict_temp, 0])
                            else:
                                off_ict_chs.append(0)
                                exp_ict_chs.append(0)
                    off_chs['chs' + str(j + 1)] = off_ict_chs
                    exp_chs['chs' + str(j + 1)] = exp_ict_chs

    split_n = 3
    data_type = 'interictal'
    if data_type == 'interictal':
        print('Now doing the interictal files...')

        SOP = 30 * 60 * sampRate
        assert tmp.shape[0] == len(chs)

        off_int[filename] = {}
        off_chs = off_int[filename]
        exp_int[filename] = {}
        exp_chs = exp_int[filename]
        off_int_smo[filename] = {}
        off_chs_smo = off_int_smo[filename]
        exp_int_smo[filename] = {}
        exp_chs_smo = exp_int_smo[filename]

        if len(szstart) > 0:
            print('%d seizures in the file %s' % (len(szstart), filename))
            for i in range(len(szstart)):
                # data_int[filename] = np.array(tmp[:, 0: SOP]
                if target == 'PN14':
                    if filename == 'PN14-3.edf':
                        data_int[filename] = np.array(tmp[:, 1200*512: 3000 * 512])
                        print('right yes yes only one seizure')
                    elif filename == 'PN14-4.edf':
                        data_int[filename] = np.array(tmp[:, 12800 * 512: 14600 * 512])
                else:
                    if i == 0:
                        data_int[filename] = np.array(tmp[:, 0: 1800 * 512])
                        print('right yes yes only one seizure')
                    elif i == 1:
                        data_int[filename] = np.array(tmp[:, 36000 * 512: 37800 * 512])

                nCHs = data_int[filename].shape[0]
                result_dir_tmp = os.path.join(result_dir_case_int, filename)
                if not os.path.exists(result_dir_tmp):
                    os.makedirs(result_dir_tmp)
                    print("seizure Folder created successfully!")
                else:
                    print("seizure Folder already exists!")

                for j in range(0, nCHs):
                    with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                              newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['offset', 'exponent', 'class'])
                    chData_int = data_int[filename][j, :]
                    nseg_int = int(np.floor(len(chData_int) / segLen))
                    segData_int = []
                    for n in range(0, nseg_int):
                        segData_int.append(chData_int[n * segLen:(n + 1) * segLen])
                    list_length = len(segData_int)
                    num_samples = divmod(list_length, split_n)[0]
                    random.seed(44)
                    random_int = random.randint(0, 2)
                    if random_int < 2:
                        segData_int = segData_int[random_int * num_samples:(random_int + 1) * num_samples]
                    else:
                        segData_int = segData_int[random_int * num_samples:]
                    segData_int = np.array(segData_int)

                    off_int_chs = []
                    exp_int_chs = []
                    for k in range(segData_int.shape[0]):
                        seg_int = segData_int[k, :]
                        f_int, pww_int = signal.welch(seg_int, fs=sampRate, nperseg=2048, noverlap=1280, nfft=2560)
                        plt_log = False
                        fm_int = FOOOF(peak_width_limits=[2, 12],
                                       max_n_peaks=6, min_peak_height=0.15, aperiodic_mode='knee')
                        fm_int.fit(f_int, pww_int, [0.5, 30])
                        if fm_int.has_model:  # 使用has_model属性来判断是否拟合成功
                            off_int_temp = fm_int.get_params('aperiodic_params')[0]
                            exp_int_temp = fm_int.get_params('aperiodic_params')[2]
                            off_int_chs.append(fm_int.get_params('aperiodic_params')[0])
                            exp_int_chs.append(fm_int.get_params('aperiodic_params')[2])
                            with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                      newline='') as csvfile:
                                writer = csv.writer(csvfile)
                                writer.writerow([off_int_temp, exp_int_temp, 1])
                        else:
                            # 调整数据的频率范围，去除过低或过高的频率
                            f_int = f_int[1:-1]
                            pww_int = pww_int[1:-1]
                            # 调整拟合设置或参数，增加最大峰值数量，降低最小峰值高度
                            fm_int = FOOOF(peak_width_limits=[1, 8],
                                           max_n_peaks=10, min_peak_height=0.1, aperiodic_mode='knee')
                            fm_int.fit(f_int, pww_int, [0.5, 30])
                            if fm_int.has_model:
                                off_int_temp = fm_int.get_params('aperiodic_params')[0]
                                exp_int_temp = fm_int.get_params('aperiodic_params')[2]
                                off_int_chs.append(fm_int.get_params('aperiodic_params')[0])
                                exp_int_chs.append(fm_int.get_params('aperiodic_params')[2])
                                with open(result_dir_tmp + '/aperiodic_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                          newline='') as csvfile:
                                    writer = csv.writer(csvfile)
                                    writer.writerow([off_int_temp, exp_int_temp, 1])
                            else:
                                off_int_chs.append(0)
                                exp_int_chs.append(0)

                    off_chs['chs' + str(j + 1)] = off_int_chs
                    exp_chs['chs' + str(j + 1)] = exp_int_chs

p_off = {}
p_exp = {}

for filename in filenames:
    with open(result_dir_aperi + '/%s.csv' % filename, 'a+', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['channel', 'p_off_avg', 'p_exp_avg'])

    off_ict_file = off_ict[filename]
    exp_ict_file = exp_ict[filename]
    p_off[filename] = {}
    p_exp[filename] = {}
    p_chs_off = p_off[filename]
    p_chs_exp = p_exp[filename]

    p_chs_off_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filenames))]
    p_chs_off_tem = np.array(p_chs_off_tem)
    p_chs_exp_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filenames))]
    p_chs_exp_tem = np.array(p_chs_exp_tem)
    for i in range(0, nCHs):
        print('now is doing the channel %d ' % i)
        off_chs_ict = off_ict_file['chs' + str(i + 1)]
        exp_chs_ict = exp_ict_file['chs' + str(i + 1)]
        for j in range(len(filenames)):
            off_chs_int = off_int[filenames[j]]['chs' + str(i + 1)]
            exp_chs_int = exp_int[filenames[j]]['chs' + str(i + 1)]
            p_off_tmp = ttest_for_p_value(off_chs_ict, off_chs_int)
            p_exp_tmp = ttest_for_p_value(exp_chs_ict, exp_chs_int)
            p_chs_off_tem[j][i] = p_off_tmp
            p_chs_exp_tem[j][i] = p_exp_tmp
        p_off_avg = np.mean(p_chs_off_tem[:, i])
        p_exp_avg = np.mean(p_chs_exp_tem[:, i])
        p_chs_off['chs' + str(i + 1)] = p_off_avg
        p_chs_exp['chs' + str(i + 1)] = p_exp_avg
        with open(result_dir_aperi + '/%s.csv' % filename, 'a+', encoding='utf-8', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['chs' + str(i + 1), p_off_avg, p_exp_avg])

    print('The channel significance order of %s was as list.' % filename)
    p_off_order = sorted(p_chs_off.items(), key=lambda x: x[1], reverse=False)
    print(p_off_order)
    p_exp_order = sorted(p_chs_exp.items(), key=lambda x: x[1], reverse=False)
    print(p_exp_order)
    print('The inference statistics of %s have been all finished.' % filename)

print('The inference statistics have been all finished.')
