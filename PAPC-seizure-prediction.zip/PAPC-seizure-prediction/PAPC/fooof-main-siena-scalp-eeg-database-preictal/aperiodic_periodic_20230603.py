import matplotlib.pyplot as plt
from fooof import FOOOF
from fooof.sim.gen import gen_aperiodic
from fooof.plts.spectra import plot_spectra
from fooof.plts.annotate import plot_annotated_peak_search
import os
import pandas as pd
import mne
import matplotlib.pyplot as plt
import numpy as np
from mne.io import RawArray, read_raw_edf
# from mne.channels import read_montage
from mne import create_info, concatenate_raws, pick_types
from mne.filter import notch_filter
from scipy import signal, stats
import csv
from collections import Counter
from imblearn.over_sampling import SMOTE
import random
import pdb


def loren_aperiodic_fit(b, freqs, exp, k=0):
    loren_ap = b - np.log10(k + freqs ** exp)
    return loren_ap


def ttest_for_p_value(cls_a, cls_b):
    # 当不确定两总体的方差是否相等时，应先利用levene检验，检验两总体方差是否具有方差齐性。
    p_std = stats.levene(cls_a, cls_b)
    if p_std[1] > 0.05:
        p_ttest = stats.ttest_ind(cls_a, cls_b)
    else:
        p_ttest = stats.ttest_ind(cls_a, cls_b, equal_var=False)
    p_value = p_ttest[1]
    return p_value


data_dir = r'E:\pythonProject\Seizure_forecasting\mnt\data4\datasets\seizure\siena-scalp-eeg-database-selected-9'
result_dir = r'E:\pythonProject\Seizure_forecasting\fooof-main-siena-scalp-eeg\statistics_result_tpw'  # 参数的特征值
if os.path.isdir(result_dir):
    pass
else:
    os.makedirs(result_dir)

#############################每次只跑一例###################################
target = 'PN17'
#############################每次只跑一例###################################

sampRate = 512

len_t = 5
segLen = sampRate * len_t

ictal_list = pd.read_csv(os.path.join(data_dir, 'seizure_info_seconds.csv'))
dir = os.path.join(data_dir, target)  # 每一个target有多少文件
text_files = [f for f in os.listdir(dir) if f.endswith('.edf')]  # 加载数据
filenames = [filename for filename in text_files]
print('filenames: ', filenames)

if target in ['PN03', 'PN05', 'PN06', 'PN07', 'PN09', 'PN12', 'PN13']:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG Cz', 'EEG Pz', 'EEG FP2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # FP2导联是大写
elif target in ['PN16', 'PN17', 'PN14']:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG CZ', 'EEG Pz', 'EEG FP2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # FP2导联是大写 CZ也是大写
else:
    chs = ['EEG Fp1', 'EEG F3', 'EEG C3', 'EEG P3', 'EEG O1', 'EEG F7', 'EEG T3', 'EEG T5', 'EEG Fc1',
           'EEG Fc5',
           'EEG Cp1', 'EEG Cp5', 'EEG F9', 'EEG Fz', 'EEG Cz', 'EEG Pz', 'EEG Fp2', 'EEG F4', 'EEG C4',
           'EEG P4',
           'EEG O2', 'EEG F8', 'EEG T4', 'EEG T6', 'EEG Fc2', 'EEG Fc6', 'EEG Cp2', 'EEG Cp6', 'EEG F10']
    # 29个通道，删去了两个EKG

result_dir_case_ict = os.path.join(result_dir, 'ictal', target)
if not os.path.exists(result_dir_case_ict):
    os.makedirs(result_dir_case_ict)
    print("case Folder for result created successfully!")
else:
    print("case Folder for result already exists!")

result_dir_case_int = os.path.join(result_dir, 'interictal', target)
if not os.path.exists(result_dir_case_int):
    os.makedirs(result_dir_case_int)
    print("case Folder for result created successfully!")
else:
    print("case Folder for result already exists!")

result_dir_tpw = os.path.join(result_dir, 'tpw', target)
if not os.path.exists(result_dir_tpw):
    os.makedirs(result_dir_tpw)
    print("TPW component Folder for result created successfully!")
else:
    print("TPW component Folder for result already exists!")

data_ict = {}
tpw1_ict = {}
tpw2_ict = {}
data_int = {}
tpw1_int = {}
tpw2_int = {}

for filename in filenames:
    edata_dir = os.path.join(dir, filename)
    rawEEG = read_raw_edf(edata_dir, verbose=0, preload=True)
    rawEEG.pick(chs)  # 选取通道
    tmp = rawEEG.to_data_frame()
    tmp = tmp.values
    print('##################', tmp.shape)
    tmp = tmp[:, 1:]
    print('##################', tmp.shape)
    print(tmp[:, 0])
    assert tmp.shape[1] == 29

    seizure_info = ictal_list[ictal_list['EDF Name'] == filename]
    szstart = seizure_info['Seizure Start Time']
    szstop = seizure_info['Seizure End Time']
    print('now process the file %s' % filename)
    print('the seizure start of this file', szstart)

    data_type = 'ictal'
    if data_type == 'ictal':
        SOP = 30 * 60 * sampRate
        SPH = 5 * 60 * sampRate
        if tmp.shape[0] == len(chs):
            pass
        else:
            tmp = tmp.T

        tpw1_ict[filename] = {}
        tpw1_chs = tpw1_ict[filename]
        tpw2_ict[filename] = {}
        tpw2_chs = tpw2_ict[filename]

        result_dir_tmp = os.path.join(result_dir_case_ict, filename)
        if not os.path.exists(result_dir_tmp):
            os.makedirs(result_dir_tmp)
            print("seizure Folder created successfully!")
        else:
            print("seizure Folder already exists!")

        if len(szstart) > 0:
            print('%d seizures in the file %s' % (len(szstart), filename))
            for i in range(len(szstart)):
                st = szstart.iloc[i] * 512 - SPH  # e.g., SPH=5min  #发作前5min的时刻数据点
                sp = szstop.iloc[i] * 512  # 发作结束时刻数据点

                data_ict[filename] = np.array(tmp[:, st - SOP: st])

                nCHs = data_ict[filename].shape[0]
                for j in range(nCHs):
                    with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                              newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['tpw1', 'tpw2', 'class'])
                    chData_ict = data_ict[filename][j, :]
                    nseg_ict = int(np.floor(len(chData_ict) / segLen))
                    print('Now is the channel %d,nseg_ict:%d' % (j, nseg_ict))
                    segData_ict = []
                    for n in range(0, nseg_ict):
                        segData_ict.append(chData_ict[n * segLen:(n + 1) * segLen])
                    segData_ict = np.array(segData_ict)
                    print("seizure %d shape of segData_ict (%d,%d)" % (i, segData_ict.shape[0], segData_ict.shape[1]))
                    tpw1_ict_chs = []
                    tpw2_ict_chs = []
                    for k in range(segData_ict.shape[0]):
                        seg_ict = segData_ict[k, :]
                        f_ict, pww_ict = signal.welch(seg_ict, fs=sampRate, nperseg=2048, noverlap=1280, nfft=2560)
                        plt_log = False
                        fm_ict = FOOOF(peak_width_limits=[2, 12],
                                       max_n_peaks=6, min_peak_height=0.15)
                        fm_ict.fit(f_ict, pww_ict, [0.5, 30])
                        cf_fit_ict = []
                        pw_fit_ict = []
                        gua_params_ict = fm_ict.get_params('peak_params')
                        [off_ict, exp_ict] = fm_ict.get_params('aperiodic_params')
                        pw_min = loren_aperiodic_fit(off_ict, 30, exp_ict)
                        if type(gua_params_ict[0]) is np.ndarray and len(gua_params_ict) == 1:
                            cf_max_ict = gua_params_ict[0][0]
                            pw_max_ict = gua_params_ict[0][1]
                            pw_2max_ict = 0
                            cf_2max_ict = 0
                            pw_max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw1_ict_tmp = pw_max_ict + (pw_max_ap - pw_min)
                            tpw2_ict_tmp = 0
                        elif type(gua_params_ict[0]) is np.ndarray and len(gua_params_ict) >= 2:
                            for t in range(len(gua_params_ict)):
                                cf_fit_ict.append(gua_params_ict[t][0])
                                pw_fit_ict.append(gua_params_ict[t][1])
                            pw_maxindex_ict = pw_fit_ict.index(max(pw_fit_ict))
                            pw_max_ict = max(pw_fit_ict)
                            cf_max_ict = cf_fit_ict[pw_maxindex_ict]
                            pw_max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw1_ict_tmp = pw_max_ict + (pw_max_ap - pw_min)
                            pw_fit_ict[pw_maxindex_ict] = float("-inf")
                            pw_2maxindex_ict = pw_fit_ict.index(max(pw_fit_ict))
                            pw_2max_ict = max(pw_fit_ict)
                            cf_2max_ict = cf_fit_ict[pw_2maxindex_ict]
                            pw_2max_ap = loren_aperiodic_fit(off_ict, cf_max_ict, exp_ict)
                            tpw2_ict_tmp = pw_2max_ict + (pw_2max_ap - pw_min)
                        else:
                            tpw1_ict_tmp = 0
                            cf_max_ict = 0
                            tpw2_ict_tmp = 0
                            cf_2max_ict = 0
                        tpw1_ict_chs.append(tpw1_ict_tmp)
                        tpw2_ict_chs.append(tpw2_ict_tmp)
                        with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8',
                                  newline='') as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow([tpw1_ict_tmp, tpw2_ict_tmp, 0])
                    tpw1_chs['chs' + str(j + 1)] = tpw1_ict_chs
                    tpw2_chs['chs' + str(j + 1)] = tpw2_ict_chs

    split_n = 3
    data_type = 'interictal'
    if data_type == 'interictal':
        print('Now doing the interictal files...')
        SOP = 30 * 60 * sampRate
        assert tmp.shape[0] == len(chs)

        tpw1_int[filename] = {}
        tpw1_chs = tpw1_int[filename]
        tpw2_int[filename] = {}
        tpw2_chs = tpw2_int[filename]

        if len(szstart) > 0:
            print('%d seizures in the file %s' % (len(szstart), filename))
            for i in range(len(szstart)):
                if target == 'PN14':
                    if filename == 'PN14-3.edf':
                        data_int[filename] = np.array(tmp[:, 1200*512: 3000 * 512])
                        print('right yes yes only one seizure')
                    elif filename == 'PN14-4.edf':
                        data_int[filename] = np.array(tmp[:, 12800 * 512: 14600 * 512])
                else:
                    if i == 0:
                        data_int[filename] = np.array(tmp[:, 0: 1800 * 512])
                        print('right yes yes only one seizure')
                    elif i == 1:
                        data_int[filename] = np.array(tmp[:, 36000 * 512: 37800 * 512])

                nCHs = data_int[filename].shape[0]
                result_dir_tmp = os.path.join(result_dir_case_int, filename)
                if not os.path.exists(result_dir_tmp):
                    os.makedirs(result_dir_tmp)
                    print("seizure Folder created successfully!")
                else:
                    print("seizure Folder already exists!")

                for j in range(0, nCHs):
                    with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8', newline='') as csvfile:
                        writer = csv.writer(csvfile)
                        writer.writerow(['tpw1', 'tpw2', 'class'])
                    chData_int = data_int[filename][j, :]
                    nseg_int = int(np.floor(len(chData_int) / segLen))
                    segData_int = []
                    for n in range(0, nseg_int):
                        segData_int.append(chData_int[n * segLen:(n + 1) * segLen])
                    list_length = len(segData_int)
                    num_samples = divmod(list_length, split_n)[0]
                    random.seed(44)
                    random_int = random.randint(0, 2)
                    if random_int < 2:
                        segData_int = segData_int[random_int * num_samples:(random_int + 1) * num_samples]
                    else:
                        segData_int = segData_int[random_int * num_samples:]
                    segData_int = np.array(segData_int)

                    tpw1_int_chs = []
                    tpw2_int_chs = []
                    cf_fit_int = []
                    pw_fit_int = []
                    for k in range(segData_int.shape[0]):
                        seg_int = segData_int[k, :]
                        f_int, pww_int = signal.welch(seg_int, fs=sampRate, nperseg=2048, noverlap=1280, nfft=2560)
                        plt_log = False
                        fm_int = FOOOF(peak_width_limits=[2, 12],
                                       max_n_peaks=6, min_peak_height=0.15)
                        fm_int.fit(f_int, pww_int, [0.5, 30])
                        gua_params_int = fm_int.get_params('peak_params')
                        [off_int, exp_int] = fm_int.get_params('aperiodic_params')
                        pw_min = loren_aperiodic_fit(off_int, 30, exp_int)
                        if type(gua_params_int[0]) is np.ndarray and len(gua_params_int) == 1:
                            cf_max_int = gua_params_int[0][0]
                            pw_max_int = gua_params_int[0][1]
                            pw_2max_int = 0
                            cf_2max_int = 0
                            w_max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                            tpw1_int_tmp = pw_max_int + (pw_max_ap - pw_min)
                            tpw2_int_tmp = 0
                        elif type(gua_params_int[0]) is np.ndarray and len(gua_params_int) >= 2:
                            for t in range(len(gua_params_int)):
                                cf_fit_int.append(gua_params_int[t][0])
                                pw_fit_int.append(gua_params_int[t][1])
                            pw_maxindex_int = pw_fit_int.index(max(pw_fit_int))
                            pw_max_int = max(pw_fit_int)
                            cf_max_int = cf_fit_int[pw_maxindex_int]
                            pw_max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                            tpw1_int_tmp = pw_max_int + (pw_max_ap - pw_min)
                            pw_fit_int[pw_maxindex_int] = float("-inf")
                            pw_2maxindex_int = pw_fit_int.index(max(pw_fit_int))
                            pw_2max_int = max(pw_fit_int)
                            cf_2max_int = cf_fit_int[pw_2maxindex_int]
                            pw_2max_ap = loren_aperiodic_fit(off_int, cf_max_int, exp_int)
                            tpw2_int_tmp = pw_2max_int + (pw_2max_ap - pw_min)
                        else:
                            tpw1_int_tmp = 0
                            cf_max_int = 0
                            tpw2_int_tmp = 0
                            cf_2max_int = 0
                        tpw1_int_chs.append(tpw1_int_tmp)
                        tpw2_int_chs.append(tpw2_int_tmp)
                        with open(result_dir_tmp + '/tpw_ch[%d].csv' % (j + 1), 'a+', encoding='utf-8', newline='') as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow([tpw1_int_tmp, tpw2_int_tmp, 1])
                    tpw1_chs['chs' + str(j + 1)] = tpw1_int_chs
                    tpw2_chs['chs' + str(j + 1)] = tpw2_int_chs

p_tpw1 = {}
p_tpw2 = {}

for filename in filenames:
    with open(result_dir_tpw + '/%s.csv' % filename, 'a+', encoding='utf-8', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['channel', 'p_tpw1_avg', 'p_tpw2_avg'])

    tpw1_ict_file = tpw1_ict[filename]
    tpw2_ict_file = tpw2_ict[filename]
    p_tpw1[filename] = {}
    p_tpw2[filename] = {}
    p_chs_tpw1 = p_tpw1[filename]
    p_chs_tpw2 = p_tpw2[filename]
    # nCHs = 21
    p_chs_tpw1_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filenames))]
    p_chs_tpw1_tem = np.array(p_chs_tpw1_tem)
    p_chs_tpw2_tem = [[0.0 for col in range(0, nCHs)] for row in range(len(filenames))]
    p_chs_tpw2_tem = np.array(p_chs_tpw2_tem)
    for i in range(0, nCHs):
        print('now is doing the channel %d ' % i)
        tpw1_chs_ict = tpw1_ict_file['chs' + str(i + 1)]
        tpw2_chs_ict = tpw2_ict_file['chs' + str(i + 1)]
        for j in range(len(filenames)):
            tpw1_chs_int = tpw1_int[filenames[j]]['chs' + str(i + 1)]
            tpw2_chs_int = tpw1_int[filenames[j]]['chs' + str(i + 1)]
            p_tpw1_tmp = ttest_for_p_value(tpw1_chs_ict, tpw1_chs_int)
            p_tpw2_tmp = ttest_for_p_value(tpw2_chs_ict, tpw2_chs_int)
            p_chs_tpw1_tem[j][i] = p_tpw1_tmp
            p_chs_tpw2_tem[j][i] = p_tpw2_tmp
        p_tpw1_avg = np.mean(p_chs_tpw1_tem[:, i])
        p_tpw2_avg = np.mean(p_chs_tpw2_tem[:, i])
        p_chs_tpw1['chs' + str(i + 1)] = p_tpw1_avg
        p_chs_tpw2['chs' + str(i + 1)] = p_tpw2_avg
        with open(result_dir_tpw + '/%s.csv' % filename, 'a+', encoding='utf-8', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['chs' + str(i + 1), p_tpw1_avg, p_tpw2_avg])

    print('The channel significance order of %s was as list.' % filename)
    p_tpw1_order = sorted(p_chs_tpw1.items(), key=lambda x: x[1], reverse=False)
    print(p_tpw1_order)
    p_tpw2_order = sorted(p_chs_tpw2.items(), key=lambda x: x[1], reverse=False)
    print(p_tpw2_order)
    print('The inference statistics of %s have been all finished.' % filename)

print('The inference statistics have been all finished.')
