from typing import KeysView
import numpy as np
import pdb
import csv
import pandas as pd
import os
import pdb

#############################每次只跑一例###################################
target = 'PN17'
#############################每次只跑一例###################################

data_dir_aperi = r'E:\pythonProject\Seizure_forecasting\fooof-main-siena-scalp-eeg\statistics_result\aperiodic'
data_dir_tpw = r'E:\pythonProject\Seizure_forecasting\fooof-main-siena-scalp-eeg\statistics_result_tpw\tpw'
result_rank_chs_dir = r'E:\pythonProject\Seizure_forecasting\fooof-main-siena-scalp-eeg\rank_chs'

if not os.path.exists(result_rank_chs_dir):
    os.makedirs(result_rank_chs_dir)
    print("case Folder for result created successfully!")
else:
    print("case Folder for result already exists!")

for i in range(len(target)):
    data_dir_aperi_tempcase = os.path.join(data_dir_aperi, target)
    data_dir_tpw_tempcase = os.path.join(data_dir_tpw, target)

    # temp_case_dir = os.path.join(result_rank_chs_dir,tempcase)
    temposfilenames_csv = [f for f in os.listdir(data_dir_aperi_tempcase) if f.endswith('csv')]
    temposfilenames = []
    char_to_remove = '.csv'
    for i in range(len(temposfilenames_csv)):
        temptemposfilenames = temposfilenames_csv[i]
        temptemposfilenames = temptemposfilenames.replace(char_to_remove, '')
        temposfilenames.append(temptemposfilenames)
    rank_chs = {}

    for filename in temposfilenames:
        print(filename)
        rank_chs[filename] = {}
        rank_chs_tempfile = rank_chs[filename]

        files_aperi = pd.read_csv(os.path.join(data_dir_aperi_tempcase, filename + '.csv'), header=0)
        files_tpw = pd.read_csv(os.path.join(data_dir_tpw_tempcase, filename + '.csv'), header=0)
        chs, p_off_avg, p_exp_avg = files_aperi['channel'], files_aperi['p_off_avg'], files_aperi['p_exp_avg']
        p_tpw1_avg, p_tpw2_avg = files_tpw['p_tpw1_avg'], files_tpw['p_tpw2_avg']
        chs = list(chs)
        print(chs)
        p_off_avg = list(p_off_avg)
        p_exp_avg = list(p_exp_avg)
        p_tpw1_avg = list(p_tpw1_avg)
        p_tpw2_avg = list(p_tpw2_avg)
        chs_off = {}
        chs_exp = {}
        chs_tpw1 = {}
        chs_tpw2 = {}
        for j in range(len(chs)):
            print(j)
            chs_off[j] = p_off_avg[j]
            chs_exp[j] = p_exp_avg[j]
            chs_tpw1[j] = p_tpw1_avg[j]
            chs_tpw2[j] = p_tpw2_avg[j]
        # pdb.set_trace() #check whether the rank of single parameter is true
        p_off_order = sorted(chs_off.items(), key=lambda x: x[1], reverse=False)  # type(p_off_order) = list
        p_exp_order = sorted(chs_exp.items(), key=lambda x: x[1], reverse=False)  # type(p_off_order[k]) = tuple
        p_tpw1_order = sorted(chs_tpw1.items(), key=lambda x: x[1], reverse=False)
        p_tpw2_order = sorted(chs_tpw2.items(), key=lambda x: x[1], reverse=False)

        chs_order_off = []
        chs_order_exp = []
        chs_order_tpw1 = []
        chs_order_tpw2 = []
        chs_order = []
        for k in range(0, 16):
            chs_order_off.append(p_off_order[k][0])
            chs_order_exp.append(p_exp_order[k][0])
            chs_order_tpw1.append(p_tpw1_order[k][0])
            chs_order_tpw2.append(p_tpw2_order[k][0])
        # pdb.set_trace()
        chs_order = [chs_order_off, chs_order_exp, chs_order_tpw1, chs_order_tpw2]
        chs_order = np.array(chs_order)
        chs_order = chs_order.T

        # pdb.set_trace()
        r_sum_4par = {}
        r_sum_3par = {}
        r_sum_2par = {}
        r_sum_1par = {}
        chs_order11 = chs_order.reshape(-1)  # reshape chs_order to 1-d array
        # check the Npar by check the repeated values
        from collections import Counter

        par_sum = Counter(chs_order11)
        par_sum = dict(par_sum)
        # pdb.set_trace()
        for key, value in par_sum.items():
            if value == 4:
                # pdb.set_trace()
                index = np.where(chs_order == int(key))
                r_sum_4par['chs' + str(key + 1)] = np.sum(index[0] + 1)
            if value == 3:
                index = np.where(chs_order == int(key))
                r_sum_3par['chs' + str(key + 1)] = np.sum(index[0] + 1)
            if value == 2:
                index = np.where(chs_order == int(key))
                r_sum_2par['chs' + str(key + 1)] = np.sum(index[0] + 1)
            if value == 1:
                index = np.where(chs_order == int(key))
                r_sum_1par['chs' + str(key + 1)] = np.sum(index[0] + 1)

        rank_chs_4par = sorted(r_sum_4par.items(), key=lambda x: x[1], reverse=False)
        rank_chs_3par = sorted(r_sum_3par.items(), key=lambda x: x[1], reverse=False)
        rank_chs_2par = sorted(r_sum_2par.items(), key=lambda x: x[1], reverse=False)
        rank_chs_1par = sorted(r_sum_1par.items(), key=lambda x: x[1], reverse=False)

        chs_rank_all = rank_chs_4par + rank_chs_3par + rank_chs_2par + rank_chs_2par + rank_chs_1par
        rank_chs_tempfile = chs_rank_all[:16]
        rank_chs[filename] = rank_chs_tempfile
        tempchslist = []
        char_to_remove = 'chs'
        for k in rank_chs[filename]:
            print(k)
            tempchs = k[0]
            tempchsint = tempchs.replace(char_to_remove, '')
            tempchslist.append(tempchsint)
        rank_chs[filename] = tempchslist
        dataframe_rank_chs = pd.DataFrame(rank_chs)
        tempcase_csv = target + '.csv'
        temp_case_dir = os.path.join(result_rank_chs_dir, tempcase_csv)
        dataframe_rank_chs.to_csv(temp_case_dir, sep=',', index=False)

