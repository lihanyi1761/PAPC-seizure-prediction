﻿
import json
import os

import os.path
import glob
import time

import numpy as np
import tensorflow.compat.v1 as tf

from utils.load_signals_st_siena import LoadSignals 
from utils.prep_data import train_val_loo_split, train_val_test_split, train_val_split, \
    train_val_test_split_14  # edf files with only seziure using the "train_val_test_split_14"
from utils.log import log

from models.cnn_gan import CNNGAN, CNNGAN_infer  
from dcgan.dcgan import DCGAN
from dcgan.wGAN_model import WGAN
from dcgan.wGAN_GP_model import WGAN_GP
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def makedirs(dir):
    try:
        os.makedirs(dir)
    except:
        pass


def main(dataset='Kaggle2014Pred', build_type='cv', sph=5):
    print('Main')

    with open('SETTINGS_%s_lhy.json' % dataset) as f:  
        settings = json.load(f)

    makedirs(str(settings['cachedir']))
    makedirs(str(settings['resultdir']))
    makedirs(str(settings['ganckptdir']))
    makedirs(str(settings['cnnckptdir']))


    if settings['dataset'] == 'CHBMIT':
        # exclude patients have too frequent seizures
        targets = [
            '1',
            # '2',
            # '3',
            # '5',
            # '6',
            # '8',
            # '9',
            # '10',
            # '11',
            # '13',
            # '14',
            # '16',
            # '17',
            # '18',
            # '19',
            # '20',
            # '21',
            # '22',
            # '23'
        ]
    elif settings['dataset'] == 'siena-scalp-eeg-database-1.0.0':
        targets = [
            # 'PN00',
            'PN01',
            # 'PN03',
            # 'PN05',
            # 'PN06',
            # 'PN07',
            # 'PN09',
            # 'PN10',
            # 'PN11',
            # 'PN12',
            # 'PN13',
            # 'PN14',
            # 'PN16',
            # 'PN17'
        ]

    summary = {}
    lines = ['clip,seizure']
    for target in targets:

        if build_type == 'save_STFT':
            if settings['dataset'] == 'siena-scalp-eeg-database-1.0.0':
                CS_channels = 29
                dir = str(settings['stftdir']) + '/ST_%s_ch%s_cs%d' % (dataset, target, CS_channels)
                makedirs(dir)
                LoadSignals(target, type='ictal', settings=settings, sph=sph, CS_channels=CS_channels).apply(
                    save_STFT=True, over_spl=False, dir=dir)
                LoadSignals(target, type='interictal', settings=settings, sph=sph, CS_channels=CS_channels).apply(
                    save_STFT=True, over_spl=False, dir=dir)

        elif build_type == 'dcgan':

            checkpoint = settings['ganckptdir'] + "/%s" % target  
            # checkpoint = settings['ganckptdir'] + "all"
            makedirs(checkpoint)
            stft_dirs = []
            stft_dirs.append(settings['stftdir'] + '/ST_%s_ch%s' % (dataset, target))
            # stft_dirs.append(settings['stftdir'] + '/ST_%s_ch%s_cs16' % (dataset, target))

            FLAGS = {}
            FLAGS["epoch"] = 20
            # FLAGS["learning_rate"] = 0.0001
            FLAGS["learning_rate"] = 0.00005
            FLAGS["beta1"] = 0.5
            FLAGS["train_size"] = np.inf
            FLAGS["batch_size"] = 128
            FLAGS["dataset"] = dataset
            FLAGS["input_fname_pattern"] = "*.jpg"
            FLAGS["checkpoint_dir"] = checkpoint
            FLAGS["sample_dir"] = "samples_%s" % dataset

            run_config = tf.compat.v1.ConfigProto()
            run_config.gpu_options.allow_growth = True

            input_height = 36
            input_width = 256
            if dataset in ['FB, CHBMIT']:  # STFT(56,112)  ST(36,256)
                input_height = 36  # 要改 数据的维度现在是(112,256)
                input_width = 256
            elif dataset in ['Kaggle2014Pred']:
                input_height = 112
                input_width = 96
            elif dataset == 'EpilepsiaSurf':
                input_height = 56
                input_width = 128

            with tf.Session(config=run_config) as sess:
                dcgan = DCGAN(sess=sess,
                              target=target,
                              checkpoint_dir=checkpoint,
                              dataset_dir=stft_dirs,
                              input_height=input_height,
                              input_width=input_width
                              )
                print('Input height and width', input_height, input_width)
                dcgan.train(FLAGS)
                print('Done training GAN')
            tf.reset_default_graph()
            # break #-- uncomment this line when training GAN  with all patients combined. i.e., only need to train once

        elif build_type == 'wgan':

            checkpoint = settings['ganckptdir'] + "/%s" % target  # need to change dcgan/model.py pattern as well
            # checkpoint = settings['ganckptdir'] + "all"
            makedirs(checkpoint)
            stft_dirs = []
            stft_dirs.append(settings['stftdir'] + '/STFT_%s_%d' % (dataset, sph))

            FLAGS = {}
            FLAGS["epoch"] = 10
            FLAGS["learning_rate"] = 0.00005
            FLAGS["beta1"] = 0.9
            FLAGS["train_size"] = np.inf
            FLAGS["batch_size"] = 64
            FLAGS["dataset"] = dataset
            FLAGS["input_fname_pattern"] = "*.jpg"
            FLAGS["checkpoint_dir"] = checkpoint
            FLAGS["sample_dir"] = "samples_%s" % dataset

            run_config = tf.ConfigProto()
            run_config.gpu_options.allow_growth = True

            input_height = 112
            input_width = 256
            if dataset in ['FB, CHBMIT']:
                input_height = 112
                input_width = 256
            elif dataset in ['Kaggle2014Pred']:
                input_height = 112
                input_width = 96
            elif dataset == 'EpilepsiaSurf':
                input_height = 56
                input_width = 128

            with tf.Session(config=run_config) as sess:
                wgan = WGAN(sess=sess,
                            target=target,
                            checkpoint_dir=checkpoint,
                            dataset_dir=stft_dirs,
                            input_height=input_height,
                            input_width=input_width
                            )
                print('Input height and width', input_height, input_width)
                wgan.train(FLAGS)
                print('Done training WGAN')
            tf.reset_default_graph()

        elif build_type == 'wgan_gp':
            CS_channels = 29
            checkpoint = settings['ganckptdir'] + "/%s" % target  # need to change dcgan/model.py pattern as well
            # checkpoint = settings['ganckptdir'] + "all"
            makedirs(checkpoint)
            stft_dirs = []
            # stft_dirs.append(settings['stftdir'] + '/ST_%s_ch%s' % (dataset, target))
            stft_dirs.append(settings['stftdir'] + '/ST_%s_ch%s_cs%d' % (dataset, target, CS_channels))

            FLAGS = {}
            FLAGS["epoch"] = 10  # origin = 10
            # FLAGS["learning_rate"] = 0.0001
            FLAGS["learning_rate_D"] = 1e-4
            FLAGS["learning_rate_G"] = 5e-5
            FLAGS["beta1"] = 0.5
            FLAGS["beta2"] = 0.9
            FLAGS["train_size"] = np.inf
            FLAGS["batch_size"] = 128  # FLAGS["batch_size"] = 128
            FLAGS["dataset"] = dataset
            FLAGS["input_fname_pattern"] = "*.npy"
            FLAGS["checkpoint_dir"] = checkpoint
            FLAGS["sample_dir"] = "samples_%s" % dataset

            run_config = tf.ConfigProto()
            run_config.gpu_options.allow_growth = True

            if dataset in ['FB, CHBMIT']:
                input_height = 36
                input_width = 256  # 008的频率是250Hz
            elif dataset == 'zhujiang':
                if target in ['001', '007']:
                    input_height = 36
                    input_width = 256
                else:
                    input_height = 36
                    input_width = 250
            elif dataset == 'siena-scalp-eeg-database-1.0.0':
                input_height = 36
                input_width = 512

            with tf.Session(config=run_config) as sess:
                wgan_gp = WGAN_GP(sess=sess,
                                  target=target,
                                  checkpoint_dir=checkpoint,
                                  dataset_dir=stft_dirs,
                                  input_height=input_height,
                                  input_width=input_width
                                  )
                print('Input height and width', input_height, input_width)
                wgan_gp.train(FLAGS)
                print('Done training WGAN_GP')
            tf.reset_default_graph()

        if build_type == 'cvgan':
            CS_channels = 29
            makedirs(str(settings['resultdir']) + "/%s" % target)
            checkpoint = settings['ganckptdir'] + "/%s" % target  # need to change dcgan/model.py pattern as well
            # checkpoint = settings['ganckptdir'] + "all" # using all data to train
            ictal_X, ictal_y = \
                LoadSignals(target, type='ictal', settings=settings, sph=sph, CS_channels=CS_channels).apply()
            interictal_X, interictal_y = \
                LoadSignals(target, type='interictal', settings=settings, sph=sph, CS_channels=CS_channels).apply()
            print("interictal_X", np.array(interictal_X).shape, np.array(interictal_X).dtype)
            print("ictal_y", np.array(ictal_y).shape, np.array(ictal_y).dtype)

            loo_folds = train_val_loo_split(ictal_X, ictal_y, interictal_X, interictal_y, 0.20)
            # loo_folds = train_val_test_split_14(ictal_X, ictal_y, interictal_X, interictal_y)

            i_loo = 1
            for X_train, y_train, X_val, y_val, X_test, y_test in loo_folds:
                print('X_train.shape, y_train.shape,X_val.shape, y_val.shape,X_test.shape, y_test.shape:',
                      X_train.shape, y_train.shape,
                      X_val.shape, y_val.shape,
                      X_test.shape, y_test.shape)

                # change to channels_last
                X_train = np.transpose(X_train, (0, 2, 3, 1))
                X_val = np.transpose(X_val, (0, 2, 3, 1))
                X_test = np.transpose(X_test, (0, 2, 3, 1))

                tempdir = '/home/lihanyi/seizure_prediction-GAN-master2/mnt/data5_2T/tempdata/CHBMIT_Movidius_cv'
                makedirs(tempdir)
                tempdir += '/%s' % target
                makedirs(tempdir)
                tempdir += '/%d' % i_loo
                makedirs(tempdir)

                makedirs(os.path.join(settings['resultdir'], '%s' % target))
                makedirs(os.path.join(settings['resultdir'], '%s/%d' % (target, i_loo)))
                makedirs(os.path.join(settings['cnnckptdir'], '%s' % target))
                makedirs(os.path.join(settings['cnnckptdir'], '%s/%d' % (target, i_loo)))

                model = CNNGAN(
                    target, nb_classes=2, mode=build_type,
                    dataset=dataset,
                    sph=sph,
                    cache=os.path.join(settings['cnnckptdir'], '%s/%d' % (target, i_loo)),
                    checkpoint=checkpoint,
                    result_dir=os.path.join(settings['resultdir'], '%s/%d' % (target, i_loo))
                )
                model.setup(X_train.shape)
                epochs = 100
                batch_size = 32
                batches = int(X_train.shape[0] / batch_size)
                steps = batches * epochs
                model.fit(X_train, y_train, X_val, y_val,
                          batch_size=batch_size, steps=steps, every_n_step=batches)
                auc = model.evaluate(X_test, y_test)
                t = '%s_%d' % (target, i_loo)
                summary[t] = auc

                # write out predictions for preictal and interictal segments
                # preictal
                X_test_p = X_test[y_test == 1]
                y_test_p = model.predict_proba(X_test_p)
                filename = os.path.join(
                    str(settings['resultdir']), 'preictal_%s_%d.csv' % (target, i_loo))
                lines = []
                lines.append('preictal')
                for i in range(len(y_test_p)):
                    lines.append('%.4f' % ((y_test_p[i][1])))
                with open(filename, 'w') as f:
                    f.write('\n'.join(lines))
                print('wrote', filename)

                # interictal
                X_test_i = X_test[y_test == 0]
                y_test_i = model.predict_proba(X_test_i)
                filename = os.path.join(
                    str(settings['resultdir']), 'interictal_%s_%d.csv' % (target, i_loo))
                lines = []
                lines.append('interictal')
                for i in range(len(y_test_i)):
                    lines.append('%.4f' % ((y_test_i[i][1])))
                with open(filename, 'w') as f:
                    f.write('\n'.join(lines))
                print('wrote', filename)

                model_infer = CNNGAN_infer(target, nb_classes=2, mode=build_type, dataset=dataset)
                model_infer.setup(X_test.shape)

                path = os.path.join(settings['resultdir'], '%s/%d' % (target, i_loo)) + '/*.meta'
                filelist = glob.glob(path)
                if len(filelist) > 0:
                    print('Checkpoint files:', filelist)
                    fn_weights = filelist[0]
                    print(fn_weights)
                    if os.path.exists(fn_weights):
                        model_infer.load_trained_weights(fn_weights[:-5])

                i_loo += 1

    print(summary)
    log(str(summary))


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", help="save_STFT, dcgan, wgan, wgan_gp, cvgan")
    parser.add_argument("--dataset", help="FB, CHBMIT or EpilepsiaSurf")
    parser.add_argument("--sph", type=int, help="0, 5, etc")
    args = parser.parse_args()
    assert args.mode in ['save_STFT', 'dcgan', 'wgan', 'wgan_gp', 'cvgan']
    log('********************************************************************')
    log('--- START --dataset %s --mode %s ---' % (args.dataset, args.mode))
    main(dataset=args.dataset, build_type=args.mode, sph=args.sph)
