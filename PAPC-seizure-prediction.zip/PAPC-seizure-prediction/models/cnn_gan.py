import os
import glob
import time
import shutil
from sklearn import metrics
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import LSTM, Activation, Dense, Dropout, Input, Flatten, Bidirectional, BatchNormalization
# from tensorflow.keras.callbacks import EarlyStopping

import numpy as np
# import np_utils
import utils
# import tensorflow as tf
import tensorflow.compat.v1 as tf
import matplotlib.pyplot as plt

from models.early_stop import EarlyStopping
# from utils.log import log
from utils.log import *
from utils import *

from dcgan.ops import lrelu, linear, concat, conv2d, batch_norm, conv3d

conv1_GAN = None


class CNNGAN():
    def __init__(self,
                 target,
                 batch_size=64,
                 nb_classes=2,
                 epochs=2,
                 mode='cv',
                 dataset='Kaggle2014Pred',
                 sph=5,
                 cache='./cache',
                 checkpoint='./checkpoint',
                 result_dir='./results'):
        self.target = target
        self.batch_size = batch_size
        self.nb_classes = nb_classes
        self.epochs = epochs
        self.mode = mode
        self.dataset = dataset
        self.cache = cache
        self.checkpoint = checkpoint
        self.result_dir = result_dir
        self.sph = sph

    def setup(self, X_shape):
        tf.reset_default_graph()
        self.x = tf.placeholder(tf.float32, [None, X_shape[1], X_shape[2], X_shape[3]])
        self.y_ = tf.placeholder(tf.float32, [None, 2])

        self.y_conv, self.training = base_cnn_lstm(self.x, X_shape, dataset=self.dataset, checkpoint=self.checkpoint,
                                                   sph=self.sph)
        self.y_conv = tf.expand_dims(self.y_conv, 1)

        dense = Dense(units=32, activation='relu', name='dense')(self.y_conv)  


        lstm1 = Bidirectional(LSTM(units=128, name='lstm'))(dense)  

        dropout_layer = Dropout(0.3)
        dropout = dropout_layer(lstm1, training=self.training)
        batch_normalization = BatchNormalization(name='batch_normalization')(dropout)

        dense_1 = Dense(units=64, activation='relu', name='dense_1')(batch_normalization)
        dropout_layer_2 = Dropout(0.3)
        dropout_2 = dropout_layer_2(dense_1, training=self.training)
        batch_normalization_2 = BatchNormalization(name='batch_normalization_2')(dropout_2)

        self.main_output = Dense(units=2, activation='sigmoid', name='main_output')(batch_normalization_2)

        self.predictions = tf.nn.softmax(self.main_output)

        with tf.name_scope('loss'):
            cross_entropy = tf.nn.softmax_cross_entropy_with_logits(
                labels=self.y_, logits=self.main_output)  
        self.cross_entropy = tf.reduce_mean(cross_entropy)

        with tf.name_scope('rmsprop_optimizer'):
            self.train_step = tf.train.RMSPropOptimizer(
                1e-4).minimize(self.cross_entropy)

        with tf.name_scope('accuracy'):
            correct_prediction = tf.equal(
                tf.argmax(self.main_output, 1), tf.argmax(self.y_, 1))
            correct_prediction = tf.cast(correct_prediction, tf.float32)
        self.accuracy = tf.reduce_mean(correct_prediction)

        self.saver = tf.train.Saver(max_to_keep=14)
        return self

    def fit(self, X_train, Y_train, X_val=None, y_val=None, batch_size=100, steps=2000, every_n_step=100):
        global conv1_GAN

        print('Start training using batch_size=%d, steps=%d, check model every %d steps'
              % (batch_size, steps, every_n_step))
        # Y_train = np_utils.to_categorical(Y_train, self.nb_classes)
        # y_val = np_utils.to_categorical(y_val, self.nb_classes)
        Y_train = np.eye(2)[Y_train]  
        print('the shape of Y_train after np.eye in def fit:', Y_train.shape)
        y_val = np.eye(2)[y_val]

        if X_val is None:
            val_size = min(int(0.25 * X_train.shape[0]), 5000) 
        else:
            val_size = 0

        def next_batch(batch_size):
            indices = np.random.permutation(X_train.shape[0] - val_size)
            xb = X_train[indices[:batch_size]]
            yb = Y_train[indices[:batch_size]]
            return [xb, yb]

        early_stop = EarlyStopping(patience=12, crit='min')  

        dum_graph = tf.Graph()
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())

            conv1 = sess.run('discriminator/d_h1_conv/w:0')

            start_time = time.time()
            start_time_1 = time.time()

            train_accuracy = 0
            train_loss = 0
            for i in range(1, steps + 1):
                batch = next_batch(batch_size)
                if i % every_n_step == 0:  
                    print('Executing time is %.1f' % (time.time() - start_time))
                    start_time = time.time()
                    train_loss /= every_n_step
                    if val_size > 0:
                        train_accuracy = self.accuracy.eval(feed_dict={
                            self.x: batch[0],
                            self.y_: batch[1],
                            self.training: False
                        })
                        val_accuracy = self.accuracy.eval(feed_dict={
                            self.x: X_train[-val_size:],
                            self.y_: Y_train[-val_size:],
                            self.training: False
                        })

                        val_loss = self.cross_entropy.eval(feed_dict={
                            self.x: X_train[-val_size:],
                            self.y_: Y_train[-val_size:],
                            self.training: False
                        })
                    else:
                        train_accuracy = self.accuracy.eval(feed_dict={
                            self.x: batch[0],  # x_train[:100]
                            self.y_: batch[1],  # y_train[:100]
                            self.training: False
                        })
                        val_accuracy = self.accuracy.eval(feed_dict={
                            self.x: X_val[:5000],  # work around for OOM
                            self.y_: y_val[:5000],
                            self.training: False
                        })
                        # train_loss = self.cross_entropy.eval(feed_dict={
                        # 	self.x: mbatch[0],
                        # 	self.y_: mbatch[1],
                        # 	self.training: False
                        # })
                        val_loss = self.cross_entropy.eval(feed_dict={
                            self.x: X_val[:5000],  # work around for OOM
                            self.y_: y_val[:5000],
                            self.training: False
                        })
                    print('Step %d: training accuracy %g, validation accuracy %g'
                          % (i, train_accuracy, val_accuracy))
                    accuracy = "%d,%.4f,%.4f" % (i, train_accuracy, val_accuracy)
                    loss = "%d,%.4f,%.4f" % (i, train_loss, val_loss)
                    log.log_acc_training(accuracy)
                    log.log_loss(loss)

                    # check if GAN trained weights were properly loaded and not changing
                    d_h1_conv = sess.run('discriminator/d_h1_conv/w:0')
                    assert (d_h1_conv == conv1_GAN).all()
                    print('ALL GOOD....')

                    save_path = self.saver.save(
                        sess, self.cache + "/%s-model-%d.ckpt" % (self.target, i))

                    stop_step = early_stop.check(i, train_loss + val_loss)  # 模型出现过拟合
                    # stop_step = early_stop.check(i, val_loss)
                    if stop_step is not None:
                        save_path = self.cache + "/%s-model-%d.ckpt" % (self.target, stop_step)
                        print(
                            "Early stopping. Optimum mode saved in file: %s" % save_path)
                        log.log("Early stopping. Optimum mode saved in file: %s" %
                                save_path)
                        break

                    train_accuracy = 0
                    train_loss = 0

                self.train_step.run(feed_dict={
                    self.x: batch[0],
                    self.y_: batch[1],
                    self.training: True})
                # _train_accuracy = self.accuracy.eval(feed_dict={
                # 			self.x: batch[0],
                # 			self.y_: batch[1],
                # 			self.training: False
                # 		})
                # train_accuracy += _train_accuracy
                _train_loss = self.cross_entropy.eval(feed_dict={
                    self.x: batch[0],
                    self.y_: batch[1],
                    self.training: False
                })
                train_loss += _train_loss

            print('Finished training classifier,executing time is %.1f' % (time.time() - start_time_1))
            self.save_path = self.cache + "/%s-model-%d.ckpt" \
                             % (self.target, early_stop.get_optimum_step())
            for suff in ['.index', '.meta', '.data-00000-of-00001']:
                shutil.copy2(
                    self.save_path + suff,
                    self.result_dir)
            log.log(self.save_path)

    def load_trained_weights(self, filename):
        self.save_path = filename
        with tf.Session() as sess:
            self.saver.restore(sess, self.save_path)
        print('Loading pre-trained weights from %s.' % filename)
        return self

    def predict_proba(self, X):
        batch_size = 1000
        n_batch = int(X.shape[0] / batch_size) + 1
        predictions_ = []
        with tf.Session() as sess:
            self.saver.restore(sess, self.save_path)
            for ie in range(n_batch):
                x_ = X[ie * batch_size: min((ie + 1) * batch_size, X.shape[0])]
                if x_.shape[0] > 0:
                    predictions_.append(self.predictions.eval(feed_dict={
                        self.x: x_,
                        self.training: False
                    }))
            predictions = np.concatenate(predictions_)
            # predictions = self.predictions.eval(feed_dict={
            #     self.x: X,
            #     # self.y_: y,
            #     self.training: False
            # })
        return predictions

    def evaluate(self, X, y):
        y = np.eye(2)[y]
        batch_size = 1000
        n_batch = int(y.shape[0] / batch_size) + 1
        print("n_batch", n_batch)
        predictions_ = []
        with tf.Session() as sess:
            self.saver.restore(sess, self.save_path)
            for ie in range(n_batch):
                x_ = X[ie * batch_size: min((ie + 1) * batch_size, X.shape[0])]
                if x_.shape[0] > 0:
                    term = self.predictions.eval(
                        feed_dict={self.x: x_, self.y_: y[ie * batch_size: min((ie + 1) * batch_size, X.shape[0])],
                                   self.training: False})
                    predictions_.append(term[:, 1])
            predictions = np.concatenate(predictions_)

            from sklearn.metrics import roc_auc_score
            from sklearn.metrics import roc_curve
            from sklearn.metrics import recall_score
            from sklearn.metrics import confusion_matrix
            from sklearn.metrics import accuracy_score

            print('ground truth:', y[:, 1])
            print('predictions:', predictions)

            fpr, tpr, threshold = roc_curve(y[:, 1], predictions)
            auc_test = roc_auc_score(y[:, 1], predictions)
            predictions = predictions.round()
            print('predictions after round:', predictions)
            accuracy = accuracy_score(y[:, 1], predictions)
            sensitivity = recall_score(y[:, 1], predictions)
            con_metr = confusion_matrix(y[:, 1], predictions)
            Specificity = con_metr[0][0] / (con_metr[0][0] + con_metr[0][1])
            print('Test AUC is:', auc_test)
            auc = "%.4f" % (auc_test)
            accuracy = "%.4f" % (accuracy)
            sensitivity = "%.4f" % (sensitivity)
            Specificity = "%.4f" % (Specificity)
            con_metr = str(con_metr)
            print('accuracy:', accuracy)
            print('sensitivity:', sensitivity)
            print('Specificity:', Specificity)
            print('confusion_matrix', con_metr)
            fpr = str(fpr)
            tpr = str(tpr)

            log.log_auc(auc)
            log.log_acc_test(accuracy)
            log.log_sen(sensitivity)
            log.log_Spe(Specificity)
            log.log_con(con_metr)
            log.log_fpr(fpr)
            log.log_tpr(tpr)

            return auc_test


# def network_biLSTM(x_train, y_train, training):
#     im_shape = (x_train.shape[1], 1)
#     inputs_lstm = Input(shape=im_shape, name='inputs_lstm')
#
#     dense = Dense(units=32, activation='relu', name='dense')(inputs_lstm)
#     lstm = Bidirectional(LSTM(units=128, name='lstm'))(dense)
#     dropout_layer = Dropout(0.3)
#     dropout = dropout_layer(lstm, training=training)
#     batch_normalization = BatchNormalization(name='batch_normalization')(dropout)
#     dense_1 = Dense(units=64, activation='relu', name='dense_1')(batch_normalization)
#     dropout_layer_2 = Dropout(0.3, name='dropout_2')
#     dropout_2 = dropout_layer_2(dense_1, training=training)
#     batch_normalization_1 = BatchNormalization(name='batch_normalization_1')(dropout_2)
#     main_output = Dense(units=2, activation='sigmoid', name='main_output')(batch_normalization_1)
#
#     return main_output, training


def base_cnn_lstm(input, X_shape, dataset='FB', checkpoint='./checkpoint', sph=5):
    global conv1_GAN

    new_graph = tf.Graph()
    meta_list = glob.glob(checkpoint + "/model_dir/*.meta")
    meta_path = max(meta_list, key=os.path.getctime)
    print(meta_path)
    with tf.Session(graph=new_graph) as sess:
        imported_meta = tf.train.import_meta_graph(meta_path)

        imported_meta.restore(
            sess,
            tf.train.latest_checkpoint(
                checkpoint + "/model_dir/"))  
        # print (tf.global_variables())
        d_h0_conv = sess.run('discriminator/d_h0_conv/w:0')
        d_h1_conv = sess.run('discriminator/d_h1_conv/w:0')
        d_h2_conv = sess.run('discriminator/d_h2_conv/w:0')

        conv1_GAN = d_h1_conv
        print('X_shape', X_shape)

    with tf.variable_scope("discriminator", reuse=tf.AUTO_REUSE) as scope:
        training = tf.placeholder(tf.bool)

        df_dim = 29 
        d_bn0 = batch_norm(name='d_bn0')
        # 批规范化
        d_bn1 = batch_norm(name='d_bn1')
        d_bn2 = batch_norm(name='d_bn2')

        h0 = lrelu(d_bn0(conv2d(input, df_dim, name='d_h0_conv', restore=True, trained_weights=d_h0_conv), train=False))
        h1 = lrelu(d_bn1(conv2d(h0, df_dim * 2, name='d_h1_conv', restore=True, trained_weights=d_h1_conv), train=False))
        h2 = lrelu(d_bn2(conv2d(h1, df_dim * 4, name='d_h2_conv', restore=True, trained_weights=d_h2_conv), train=False))

        fl = tf.layers.flatten(inputs=h2)

        return fl, training


class CNNGAN_infer(CNNGAN):
    def setup(self, X_shape):
        tf.reset_default_graph()
        print('X_shape', X_shape)
        self.x = tf.placeholder(tf.float32, [1, X_shape[1], X_shape[2], X_shape[3]], name='input')

        # Build the graph for the deep net
        y_conv = base_cnn_lstm_infer(self.x)
        y_conv = tf.expand_dims(y_conv, 1)
        dense = Dense(units=32, activation='relu', name='dense')(y_conv)

        lstm1 = Bidirectional(LSTM(units=128, name='lstm'))(dense)
        # lstm1 = LSTM(units=128, return_sequences=True, name='lstm1')(y_conv)
        batch_normalization = BatchNormalization(name='batch_normalization')(lstm1)

        # lstm2 = LSTM(units=128, name='lstm2')(batch_normalization)
        # batch_normalization_1 = BatchNormalization(name='batch_normalization_1')(lstm2)

        dense_1 = Dense(units=64, activation='relu', name='dense_1')(batch_normalization)
        batch_normalization_2 = BatchNormalization(name='batch_normalization_2')(dense_1)

        main_output = Dense(units=2, activation='sigmoid', name='main_output')(batch_normalization_2)
        output = tf.nn.softmax(main_output, name='output')

        self.predictions = output
        self.training = tf.placeholder(tf.bool)  # not used, just to make compatible with training code
        return self

    def load_trained_weights(self, filename):
        self.save_path = filename
        self.saver = tf.train.Saver(tf.global_variables())
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            sess.run(tf.local_variables_initializer())
            self.saver.restore(sess, filename)
            self.saver.save(sess, filename + '-inference')
        print('Save inference model to %s-inference.' % filename)
        return self


def base_cnn_lstm_infer(input):
    with tf.variable_scope("discriminator", reuse=tf.AUTO_REUSE) as scope:
        df_dim = 29  # 按照通道变化

        d_bn0 = batch_norm(name='d_bn0')
        # batch_norm批规范化
        d_bn1 = batch_norm(name='d_bn1')
        d_bn2 = batch_norm(name='d_bn2')

        h0 = lrelu(d_bn0(conv2d(input, df_dim, name='d_h0_conv'), train=False))
        h1 = lrelu(d_bn1(conv2d(h0, df_dim * 2, name='d_h1_conv'), train=False))
        h2 = lrelu(d_bn2(conv2d(h1, df_dim * 4, name='d_h2_conv'), train=False))
        # fl = h2
        fl = tf.layers.flatten(inputs=h2)

        return fl
