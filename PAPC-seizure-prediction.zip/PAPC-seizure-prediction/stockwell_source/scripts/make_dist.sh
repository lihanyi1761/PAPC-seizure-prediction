#!/bin/bash
cd ..
python setup.py sdist --formats=gztar,zip
cd -
