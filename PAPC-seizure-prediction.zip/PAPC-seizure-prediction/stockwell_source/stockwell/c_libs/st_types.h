enum WINDOW {GAUSS, KAZEMI};
// extern enum WINDOW window_type;