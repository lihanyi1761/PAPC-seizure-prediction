import os
import time
import glob
import datetime
import numpy as np
import pandas as pd
import scipy.io
from scipy.signal import resample
import pywt  # replace stft to pywt
from stockwell import st

import matplotlib.pyplot as plt


from myio.save_load import save_pickle_file, load_pickle_file, \
    save_hickle_file, load_hickle_file


def load_signals_CHBMIT(data_dir, target, data_type, sph, CS_channels):
    print('load_signals_CHBMIT for Patient', target, 'using SPH =', sph)
    from mne.io import RawArray, read_raw_edf

    onset = pd.read_csv(os.path.join(data_dir, 'seizure_summary.csv'), header=0)
    osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']
    osfilenames = list(osfilenames) 

    segment = pd.read_csv(os.path.join(data_dir, 'segmentation.csv'), header=None)
    nsfilenames = list(segment[segment[1] == 0][0])  

    nsdict = {
        '0': []
    }
    targets = [
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12',
        '13',
        '14',
        '15',
        '16',
        '17',
        '18',
        '19',
        '20',
        '21',
        '22',
        '23'
    ]
    for t in targets:
        nslist = [elem for elem in nsfilenames if
                  elem.find('chb%s_' % t) != -1 or
                  elem.find('chb0%s_' % t) != -1 or
                  elem.find('chb%sa_' % t) != -1 or
                  elem.find('chb%sb_' % t) != -1 or
                  elem.find('chb%sc_' % t) != -1]  
        nsdict[t] = nslist

    special_interictal = pd.read_csv(os.path.join(data_dir, 'special_interictal.csv'), header=None)
    sifilenames, sistart, sistop = special_interictal[0], special_interictal[1], special_interictal[2]
    sifilenames = list(sifilenames)

    def strcv(i):
        if i < 10:
            return '0' + str(i)
        elif i < 100:
            return str(i)

    strtrg = 'chb' + strcv(int(target)) 
    dir = os.path.join(data_dir, strtrg)
    text_files = [f for f in os.listdir(dir) if f.endswith('.edf')]  

    if data_type == 'ictal':
        filenames = [filename for filename in text_files if filename in osfilenames]
    elif data_type == 'interictal':
        filenames = [filename for filename in text_files if filename in nsdict[target]]

    totalfiles = len(filenames)
    print('Total %s files %d' % (data_type, totalfiles)) 

    print('filenames: ', filenames)
    # filenames: %s ['chb01_03.edf', 'chb01_04.edf', 'chb01_18.edf', 'chb01_26.edf', 'chb01_15.edf']
    for filename in filenames:
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3', u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4',
               u'F4-C4', u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0', u'P8-O2', u'FZ-CZ', u'CZ-PZ',
               u'T7-FT9', u'FT9-FT10', u'FT10-T8']  

        from utils.CHBMIT_channels import channels

        if CS_channels != 21:
            significant_channels = channels['%s' % target]  
            significant_channels = significant_channels[:CS_channels]
            print('为给定文件%s选择%d个通道' % (filename, CS_channels), significant_channels)
            chs = np.array(chs)[significant_channels]
            print('选择的通道名称', chs)

        rawEEG = read_raw_edf('%s/%s' % (dir, filename), verbose=0, preload=True)
        rawEEG.pick_channels(chs)  
        tmp = rawEEG.to_data_frame()
        tmp = tmp.values
        print('##################', tmp.shape)
        tmp = tmp[:, 1:]
        print('##################', tmp.shape)
        print(tmp[:, 0])
        assert tmp.shape[1] == CS_channels

        if data_type == 'ictal':
            SOP = 30 * 60 * 256
            indices = [ind for ind, x in enumerate(osfilenames) if x == filename]
            print('indices:', indices)
            if len(indices) > 0:
                print('%d seizures in the file %s' % (len(indices), filename))
                prev_sp = -1e6
                for i in range(len(indices)):
                    st = szstart[indices[i]] * 256 - sph * 60 * 256 
                    sp = szstop[indices[i]] * 256  
                    

                    if filename[6] == '_': 
                        seq = int(filename[7:9])
                    else:
                        seq = int(filename[6:8])
                    if filename == 'chb02_16+.edf':
                        prevfile = 'chb02_16.edf'
                    else:
                        if filename[6] == '_':
                            prevfile = '%s_%s.edf' % (filename[:6], strcv(seq - 1))
                        else:
                            prevfile = '%s_%s.edf' % (filename[:5], strcv(seq - 1))

                    if st - SOP > prev_sp: 
                        prev_sp = sp  # sp = szstop[indices[i]]*256 ##发作结束时刻数据点
                        if st - SOP >= 0:
                            data = tmp[st - SOP: st, :]  # 取发作前5min+SOP时间，至发作前5min
                            print('data shape', data.shape)
                        else:
                            if os.path.exists('%s/%s' % (dir, prevfile)):
                                rawEEG = read_raw_edf('%s/%s' % (dir, prevfile), verbose=0, preload=True)
                                rawEEG.pick_channels(chs)
                                prevtmp = rawEEG.to_data_frame()
                                prevtmp = prevtmp.values
                                print('##################', prevtmp.shape)
                                prevtmp = prevtmp[:, 1:]
                                print('##################', prevtmp.shape)
                                print(prevtmp[:, 0])
                                assert prevtmp.shape[1] == CS_channels

                                if st > 0:
                                    data = np.concatenate((prevtmp[st - SOP:, :], tmp[:st, :]))  # 取发作文件前一个文件的数据，补足SOP时间
                                else:
                                    data = prevtmp[st - SOP:st, :]

                            else:
                                if st > 0:
                                    data = tmp[:st, :]
                                else:
                                    print("WARNING: file %s does not contain useful info" % filename)
                                    continue
                    else:
                        prev_sp = sp
                        continue

                    if data.shape[0] == SOP:
                        yield data
                    else:
                        continue

        elif data_type == 'interictal':
            if filename in sifilenames:  
                st = sistart[sifilenames.index(filename)]
                sp = sistop[sifilenames.index(filename)]
                if sp < 0:
                    data = tmp[st * 256:, :]
                else:
                    data = tmp[st * 256:sp * 256, :]
            else:
                data = tmp[10 * 60 * 256:40 * 60 * 256, :]
            print('interictal data shape', data.shape)
            yield data


class LoadSignals():
    def __init__(self, target, type, settings, sph, CS_channels):
        self.target = target
        self.settings = settings
        self.type = type
        self.sph = sph
        self.CS_channels = CS_channels
        self.global_proj = np.array([0.0] * 114)
        self.significant_channels = None

    def read_raw_signal(self):
        if self.settings['dataset'] == 'CHBMIT':
            self.samp_freq = 256
            self.freq = 256
            self.global_proj = np.array([0.0] * 114)

            from utils.CHBMIT_channels import channels
            try:
                self.significant_channels = channels[self.target]
            except:
                pass
            print('target %s chosen significant channel %s' % (self.target, self.significant_channels))
            return load_signals_CHBMIT(self.settings['datadir'], self.target, self.type, self.sph, self.CS_channels)

    def preprocess(self, data_):
        ictal = self.type == 'ictal'
        interictal = self.type == 'interictal'
        targetFrequency = self.freq  
        numts = 1

        df_sampling = pd.read_csv(
            'sampling_%s.csv' % self.settings['dataset'],
            header=0, index_col=None)
        trg = int(self.target)
        print(df_sampling)  
        ictal_ovl_pt = \
            df_sampling[df_sampling.Subject == trg].ictal_ovl.values[0]
        print("ictal_ovl_pt:", ictal_ovl_pt)
        ictal_ovl_len = int(targetFrequency * ictal_ovl_pt * numts)  

        from utils.CHBMIT_channels import channels

        def process_raw_data(mat_data):
            print('loading data')
            X = []
            y = []
            for data in mat_data:
                if ictal:
                    y_value = 1
                else:
                    y_value = 0

                X_temp = []
                y_temp = []
                print('the original shape of data before doing cwt:', data.shape)

                totalSample = int(data.shape[0] / targetFrequency / numts) + 1 
                print('totalsample:', totalSample)
                window_len = int(targetFrequency * numts)  
                for i in range(totalSample):
                    if (i + 1) * window_len <= data.shape[0]:
                        s = data[i * window_len:(i + 1) * window_len, :]  

                        def timeFrequenciesST(data):
                            fmin = 0  # Hz
                            fmax = 35  # Hz
                            df = 1. / numts  
                            # print('df', df)
                            fmin_samples = int(fmin / df)
                            fmax_samples = int(fmax / df)
                            for j in range(data.shape[1]):
                                data_ = data[:, j]
                                strans_EEG = st.st(data_, fmin_samples, fmax_samples)  
                                strans_EEG = abs(strans_EEG)
                                strans_EEG = maxminnorm(strans_EEG)
                                if j == 0:
                                    stmatr_ = np.empty((data.shape[1], strans_EEG.shape[0], strans_EEG.shape[1]),
                                                       dtype='float')
                                    stmatr_[j, :, :] = strans_EEG
                                else:
                                    stmatr_[j, :, :] = strans_EEG

                            return stmatr_

                        def maxminnorm(array):
                            max = np.max(array)
                            min = np.min(array)
                            array = (array - min) / (max - min)
                            return array

                        st_data = timeFrequenciesST(s)
                        st_data = np.abs(st_data)
                        st_data = st_data.reshape(-1, st_data.shape[0], st_data.shape[1], st_data.shape[2])

                        X_temp.append(st_data)
                        y_temp.append(y_value)

                print('now finished first st to ictal data,the st_data shape is: ', np.array(X_temp).shape)

                if len(X_temp) > 0:
                    X_temp = np.concatenate(X_temp, axis=0)
                    y_temp = np.array(y_temp)
                    X.append(X_temp)
                    y.append(y_temp)

            if ictal or interictal:
                try:
                    print('X:', len(X), X[0].shape, 'y:', len(y), y[0].shape)
                except:
                    print('!!!!!!!!!!!!DEBUG!!!!!!!!!!!!!:', X)
                return X, y
            else:
                print('X', X.shape)
                return X

        data = process_raw_data(data_)

        return data

    def apply(self, save_STFT=False, over_spl=False, dir=''):
        def save_STFT_to_files(X):
            pre = None  # oversampling for GAN training
            ovl_pct = 0.1
            if isinstance(X, list):
                index = 0
                ovl_len = int(ovl_pct * X[0].shape[-1])  # oversampling for GAN training ovl_len =25
                print("X[0].shape[-2]:", X[0].shape[-1])
                print("ovl_len:", ovl_len)
                ovl_num = int(np.floor(1.0 / ovl_pct) - 1)  # oversampling for GAN training 9
                print("ovl_num:", ovl_num)
                for x in X:
                    for i in range(x.shape[0]):
                        # print('x.shape[0]:',x.shape[0])
                        fn = '%s_%s_%d_%d.npy' % (self.target, self.type, index, i)
                        if self.settings['dataset'] in ['FB', 'CHBMIT']:
                            x_ = x[i, :, :, :]
                        np.save(os.path.join(dir, fn), x_)
                        # Generate overlapping samples for GAN
                        if over_spl:
                            if i > 0:
                                for j in range(1, ovl_num + 1):
                                    fn = '%s_ovl_%s_%d_%d_%d.npy' % (self.target, self.type, index, i, j)
                                    x_2 = np.concatenate((pre[:, :, :j * ovl_len], x_[:, :, j * ovl_len:]), axis=2)
                                    print('the shape of ictal cwt_data if over_spl:', x_2.shape)
                                    assert x_2.shape == x_.shape
                                    np.save(os.path.join(dir, fn), x_2)

                            pre = x_
                    index += 1
            else:
                ovl_len = int(ovl_pct * X.shape[-2])  # oversampling for GAN training
                ovl_num = np.floor(1.0 / ovl_pct) - 1  # oversampling for GAN training
                index = 0
                for i in range(X.shape[0]):
                    fn = '%s_%s_0_%d.npy' % (self.target, self.type, i)
                    if self.settings['dataset'] in ['FB', 'CHBMIT']:
                        x_ = X[i, :, :, :]
                    np.save(os.path.join(dir, fn), x_)
                    # Generate overlapping samples for GAN
                    if over_spl:
                        if i > 0:
                            for j in range(1, ovl_num + 1):
                                fn = '%s_ovl_%s_%d_%d_%d.npy' % (self.target, self.type, index, i, j)
                                x_2 = np.concatenate((pre[:, :, :j * ovl_len * 256], x_[:, :, j * ovl_len * 256:]),
                                                     axis=-1)
                                print('the shape of interictal cwt_data if over_spl:', x_2.shape)
                                assert x_2.shape == x_.shape
                                np.save(os.path.join(dir, fn), x_2)
                        pre = x_
                index += 1

            print('Finished saving ST to %s, exceuting time is %.1f' % (dir, time.time() - start_time_s1))
            return None

        start_time_s1 = time.time()
        filename = '%s_%s' % (self.type, self.target)
        # 作图要注释
        cache = load_hickle_file(
            os.path.join(self.settings['cachedir'], filename))
        if cache is not None:
            if save_STFT:
                X, _ = cache
                return save_STFT_to_files(X)
            else:
                return cache

        data = self.read_raw_signal()
        if self.settings['dataset'] == 'Kaggle2014Pred':
            X, y = self.preprocess_Kaggle(data)
        else:
            X, y = self.preprocess(data)
        print('the filename of save_hickle_file:', os.path.join(self.settings['cachedir'], filename))
        save_hickle_file(os.path.join(self.settings['cachedir'], filename), [X, y])

        if save_STFT:
            return save_STFT_to_files(X)
        else:
            return X, y
