import os
from datetime import datetime


def log(text, fn='log'):
    with open(fn, 'a+') as f:
        string = str(datetime.now()) + ': ' + text + '\r\n'
        f.write(string)


def log_loss(loss, fn='log_loss'):
    with open(fn, 'a+') as f:
        string = loss + '\r\n'
        f.write(string)


def log_index(indexs, fn='log_index'):
    with open(fn, 'a+') as f:
        string = indexs + '\r\n'
        f.write(string)


def log_acc_training(accuracy, fn='log_acc_training'):
    with open(fn, 'a+') as f:
        string = accuracy + '\r\n'
        f.write(string)


def log_acc_test(accuracy, fn='log_acc_test'):
    with open(fn, 'a+') as f:
        string = accuracy + '\r\n'
        f.write(string)


def log_auc(auc, fn='log_auc'):
    with open(fn, 'a+') as f:
        string = auc + '\r\n'
        f.write(string)


def log_fpr(fpr, fn='log_fpr'):
    with open(fn, 'a+') as f:
        string = fpr + '\r\n'
        f.write(string)


def log_tpr(tpr, fn='log_tpr'):
    with open(fn, 'a+') as f:
        string = tpr + '\r\n'
        f.write(string)


def log_sen(sensitivity, fn='log_sen'):
    with open(fn, 'a+') as f:
        string = sensitivity + '\r\n'
        f.write(string)


def log_Spe(Specificity, fn='log_Spe'):
    with open(fn, 'a+') as f:
        string = Specificity + '\r\n'
        f.write(string)


def log_con(con_metr, fn='log_con'):
    with open(fn, 'a+') as f:
        string = con_metr + '\r\n'
        f.write(string)
