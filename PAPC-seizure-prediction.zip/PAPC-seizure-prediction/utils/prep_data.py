import numpy as np


def train_val_loo_split(ictal_X_uniform, ictal_y_uniform, interictal_X, interictal_y, ictal_X, ictal_y, val_ratio):
    '''
    Prepare data for leave-one-out cross-validation
    :param ictal_X_uniform : 
    :param ictal_y_uniform :
    :param interictal_X : interictal_X_adapt
    :param interictal_y : interictal_y_adapt
    :param ictal_X : ictal_X_adapt 
    :param ictal_y : ictal_y_adapt

    :return: (X_train, y_train, X_val, y_val, X_test, y_test)
    '''

    nfold = len(ictal_y) 

    if isinstance(interictal_y, list):
        interictal_X = np.concatenate(interictal_X, axis=0)  
        interictal_y = np.concatenate(interictal_y, axis=0) 
    interictal_fold_len = int(round(1.0 * interictal_y.shape[0] / nfold))
    print('interictal_fold_len', interictal_fold_len) 

    for i in range(nfold):
        X_test_ictal = ictal_X_uniform[i]  
        y_test_ictal = ictal_y_uniform[i]

        X_test_interictal = interictal_X[i * interictal_fold_len:(i + 1) * interictal_fold_len]
        y_test_interictal = interictal_y[i * interictal_fold_len:(i + 1) * interictal_fold_len]

        if i == 0:
            if nfold == 2:
                X_train_ictal = ictal_X[1]
                y_train_ictal = ictal_y[1]
            else:
                X_train_ictal = np.concatenate(ictal_X[1:], axis=0)
                y_train_ictal = np.concatenate(ictal_y[1:], axis=0)

            # X_train_interictal = interictal_X[(i + 1) * interictal_fold_len + 1:] 
            # y_train_interictal = interictal_y[(i + 1) * interictal_fold_len + 1:]
            X_train_interictal = interictal_X[(i + 1) * interictal_fold_len:] 
            y_train_interictal = interictal_y[(i + 1) * interictal_fold_len:]
        elif i < nfold - 1:
            X_train_ictal = np.concatenate(ictal_X[:i] + ictal_X[i + 1:], axis=0)
            y_train_ictal = np.concatenate(ictal_y[:i] + ictal_y[i + 1:], axis=0)

            # X_train_interictal = np.concatenate(
            #     [interictal_X[:i * interictal_fold_len], interictal_X[(i + 1) * interictal_fold_len + 1:]], axis=0)
            # y_train_interictal = np.concatenate(
            #     [interictal_y[:i * interictal_fold_len], interictal_y[(i + 1) * interictal_fold_len + 1:]], axis=0)
            X_train_interictal = np.concatenate(
                [interictal_X[:i * interictal_fold_len], interictal_X[(i + 1) * interictal_fold_len:]], axis=0)
            y_train_interictal = np.concatenate(
                [interictal_y[:i * interictal_fold_len], interictal_y[(i + 1) * interictal_fold_len:]], axis=0)
        else:
            if nfold == 2:
                X_train_ictal = ictal_X[0]
                y_train_ictal = ictal_y[0]
            else:
                X_train_ictal = np.concatenate(ictal_X[:i], axis=0)
                y_train_ictal = np.concatenate(ictal_y[:i], axis=0)

            X_train_interictal = interictal_X[:i * interictal_fold_len]
            y_train_interictal = interictal_y[:i * interictal_fold_len]

        print(y_train_ictal.shape, y_train_interictal.shape)  # (1770,) (1748,0)

        '''
        Downsampling interictal training set so that the 2 classes
        are balanced
        '''
        down_spl = int(np.floor(y_train_interictal.shape[0] / y_train_ictal.shape[0]))
        print('down_spl:', down_spl)  # 0
        if down_spl > 1:
            X_train_interictal = X_train_interictal[::down_spl]
            y_train_interictal = y_train_interictal[::down_spl]
        elif down_spl == 1:
            X_train_interictal = X_train_interictal[:X_train_ictal.shape[0]]
            y_train_interictal = y_train_interictal[:X_train_ictal.shape[0]]

        print('Balancing:', y_train_ictal.shape, y_train_interictal.shape)

        X_train = np.concatenate((X_train_ictal[:int(X_train_ictal.shape[0] * (1 - val_ratio))],
                                  X_train_interictal[:int(X_train_interictal.shape[0] * (1 - val_ratio))]), axis=0)
        y_train = np.concatenate((y_train_ictal[:int(X_train_ictal.shape[0] * (1 - val_ratio))],
                                  y_train_interictal[:int(X_train_interictal.shape[0] * (1 - val_ratio))]), axis=0)

        X_val = np.concatenate((X_train_ictal[int(X_train_ictal.shape[0] * (1 - val_ratio)):],
                                X_train_interictal[int(X_train_interictal.shape[0] * (1 - val_ratio)):]), axis=0)
        y_val = np.concatenate((y_train_ictal[int(X_train_ictal.shape[0] * (1 - val_ratio)):],
                                y_train_interictal[int(X_train_interictal.shape[0] * (1 - val_ratio)):]), axis=0)

        nb_val = X_val.shape[0] - X_val.shape[0] % 4
        print('nb_val:', nb_val)  # 880
        X_val = X_val[:nb_val]
        y_val = y_val[:nb_val]

        # let overlapped ictal samples have same labels with non-overlapped samples
        y_train[y_train == 2] = 1
        y_val[y_val == 2] = 1

        X_test = np.concatenate((X_test_ictal, X_test_interictal), axis=0)
        y_test = np.concatenate((y_test_ictal, y_test_interictal), axis=0)

        # remove overlapped ictal samples in test-set
        X_test = X_test[y_test != 2]
        y_test = y_test[y_test != 2]
        print('==========================', np.unique(y_test_ictal))
        print('==========================', np.unique(y_test_interictal))
        print('==========================', np.unique(y_test))
        print('X_train, X_val, X_test', X_train.shape, X_val.shape,
              X_test.shape)  # (2880, 16, 36, 256) (720, 16, 36, 256) (3600, 16, 36, 256)
        yield X_train, y_train, X_val, y_val, X_test, y_test


def train_val_test_split_14(ictal_X, ictal_y, interictal_X, interictal_y, train_ratio=3 / 4, val_ratio=0.25):
    if isinstance(interictal_y, list):
        interictal_X = np.concatenate(interictal_X, axis=0)  # 1800*3,112,256,161
        interictal_y = np.concatenate(interictal_y, axis=0)  # 5400
        print("interictal_X, interictal_y", interictal_X.shape[0], interictal_y.shape[0])

    ictal_X = np.squeeze(ictal_X, axis=0)  # 1800,112,256,16
    ictal_y = np.squeeze(ictal_y, axis=0)  # 1800
    ictal_train_X_len = int(ictal_X.shape[0] * train_ratio)  # 1200,1112,256,16
    ictal_train_y_len = int(ictal_y.shape[0] * train_ratio)  # 1200

    interictal_train_X_len = int(interictal_X.shape[0] * train_ratio)  # 3600,112,256,16
    interictal_train_y_len = int(interictal_y.shape[0] * train_ratio)  # 3600

    X_train_ictal = ictal_X[:ictal_train_X_len]
    y_train_ictal = ictal_y[:ictal_train_y_len]

    X_train_interictal = interictal_X[:interictal_train_X_len]
    y_train_interictal = interictal_y[:interictal_train_y_len]

    X_test_ictal = ictal_X[ictal_train_X_len:]  
    y_test_ictal = ictal_y[ictal_train_y_len:]

    X_test_interictal = interictal_X[interictal_train_X_len:]  
    y_test_interictal = interictal_y[interictal_train_y_len:]

    print(y_train_ictal.shape, y_train_interictal.shape)  # 1200     3600
    print('................', y_test_ictal.shape, y_test_interictal.shape)
    '''
    Downsampling interictal training set so that the 2 classes
    are balanced
    '''
    # down_spl = int(np.floor(y_train_interictal.shape[0] / y_train_ictal.shape[0]))  # 3
    # if down_spl > 1:
    #     X_train_interictal = X_train_interictal[::down_spl]
    #     y_train_interictal = y_train_interictal[::down_spl]
    # elif down_spl == 1:
    #     X_train_interictal = X_train_interictal[:X_train_ictal.shape[0]]
    #     y_train_interictal = y_train_interictal[:X_train_ictal.shape[0]]

    print('Balancing:', y_train_ictal.shape, y_train_interictal.shape)  # 3600，  3600，

    # X_train_ictal = shuffle(X_train_ictal,random_state=0)
    # X_train_interictal = shuffle(X_train_interictal,random_state=0)
    X_train = np.concatenate((X_train_ictal[:int(X_train_ictal.shape[0] * (1 - val_ratio))],
                              X_train_interictal[:int(X_train_interictal.shape[0] * (1 - val_ratio))]), axis=0)
    y_train = np.concatenate((y_train_ictal[:int(X_train_ictal.shape[0] * (1 - val_ratio))],
                              y_train_interictal[:int(X_train_interictal.shape[0] * (1 - val_ratio))]), axis=0)

    X_val = np.concatenate((X_train_ictal[int(X_train_ictal.shape[0] * (1 - val_ratio)):],
                            X_train_interictal[int(X_train_interictal.shape[0] * (1 - val_ratio)):]), axis=0)
    y_val = np.concatenate((y_train_ictal[int(X_train_ictal.shape[0] * (1 - val_ratio)):],
                            y_train_interictal[int(X_train_interictal.shape[0] * (1 - val_ratio)):]), axis=0)

    nb_val = X_val.shape[0] - X_val.shape[0] % 4
    X_val = X_val[:nb_val]
    y_val = y_val[:nb_val]

    # let overlapped ictal samples have same labels with non-overlapped samples
    y_train[y_train == 2] = 1
    y_val[y_val == 2] = 1

    X_test = np.concatenate((X_test_ictal, X_test_interictal), axis=0)
    y_test = np.concatenate((y_test_ictal, y_test_interictal), axis=0)
    # print('gggggggggggggggggg', X_test.shape, y_test.shape)
    # remove overlapped ictal samples in test-set
    X_test = X_test[y_test != 2]
    y_test = y_test[y_test != 2]

    print('X_train, X_val, X_test', X_train.shape, X_val.shape, X_test.shape)
    yield X_train, y_train, X_val, y_val, X_test, y_test