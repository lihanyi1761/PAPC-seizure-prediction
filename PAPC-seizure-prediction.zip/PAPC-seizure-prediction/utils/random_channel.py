# 导入random模块
import random

import numpy as np
from utils.CHBMIT_channels import channels

chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3', u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4',
       u'F4-C4', u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8-0', u'P8-O2', u'FZ-CZ', u'CZ-PZ',
       u'T7-FT9', u'FT9-FT10', u'FT10-T8']

# '1': np.array([1, 2, 5, 6, 7, 8, 9, 13, 14, 20, 3, 4, 16, 18, 10, 17]),  # patient-PAPC
# 'chb01_03.edf': np.array([2, 14, 5, 8, 18, 7, 3, 6, 9, 1, 17, 20, 4, 16, 10, 13]),  # 自适应通道，前16个
# 'chb01_04.edf': np.array([2, 5, 14, 8, 18, 9, 7, 4, 20, 17, 13, 16, 1, 10, 6, 3]),  # 自适应通道，前16个
# 'chb01_15.edf': np.array([5, 8, 13, 9, 17, 2, 20, 4, 14, 7, 3, 6, 12, 0, 16, 1]),  # 自适应通道，前16个
# 'chb01_18.edf': np.array([8, 5, 2, 4, 18, 7, 12, 14, 13, 1, 9, 16, 20, 19, 0, 6]),  # 自适应通道，前16个
# 'chb01_26.edf': np.array([7, 14, 13, 20, 5, 18, 6, 19, 10, 1, 3, 2, 15, 11, 8, 9]),  # 自适应通道，前16个

# '9': np.array([3, 16, 0, 7, 1, 18, 2, 17, 11, 6, 5, 4, 14, 19, 9, 10]),  # patient-PAPC
# 'chb09_06.edf': np.array([0, 18, 3, 1, 2, 14, 16, 4, 19, 17, 11, 6, 5, 9, 7, 15]),  # 自适应通道，前16个
# 'chb09_08.edf': np.array([3, 11, 16, 7, 17, 14, 2, 18, 6, 5, 1, 10, 0, 15, 13, 20]),  # 自适应通道，前16个
# 'chb09_19.edf': np.array([7, 16, 4, 0, 8, 3, 5, 1, 6, 17, 9, 11, 2, 18, 10, 19]),  # 自适应通道，前16个
# 定义一个列表，包含16个数字
chb1 = [1, 2, 5, 6, 7, 8, 9, 13, 14, 20, 3, 4, 16, 18, 10, 17]
# chb01_03 = [2, 14, 5, 8, 18, 7, 3, 6, 9, 1, 17, 20, 4, 16, 10, 13]
# chb01_04 = [2, 5, 14, 8, 18, 9, 7, 4, 20, 17, 13, 16, 1, 10, 6, 3]
# chb01_15 = [5, 8, 13, 9, 17, 2, 20, 4, 14, 7, 3, 6, 12, 0, 16, 1]
# chb01_18 = [8, 5, 2, 4, 18, 7, 12, 14, 13, 1, 9, 16, 20, 19, 0, 6]
# chb01_26 = [7, 14, 13, 20, 5, 18, 6, 19, 10, 1, 3, 2, 15, 11, 8, 9]
chb9 = [3, 16, 0, 7, 1, 18, 2, 17, 11, 6, 5, 4, 14, 19, 9, 10]
# chb09_06 = [0, 18, 3, 1, 2, 14, 16, 4, 19, 17, 11, 6, 5, 9, 7, 15]
# chb09_08 = [3, 11, 16, 7, 17, 14, 2, 18, 6, 5, 1, 10, 0, 15, 13, 20]
# chb09_19 = [7, 16, 4, 0, 8, 3, 5, 1, 6, 17, 9, 11, 2, 18, 10, 19]


seizures = [chb1, chb1, chb1]

selected_patient = []

for j in seizures:
    selected = []

    j = j[:4]
    print('my choice', j)
    channels_all = np.arange(0, 21)
    print('all channels', channels_all)
    channels_to_select = np.setdiff1d(channels_all, j)
    print('to select channels', channels_to_select)
    for i in range(4):

        choice = random.choice(channels_to_select)
        selected.append(choice)

        channels_to_select = np.delete(channels_to_select, np.where(channels_to_select == choice))
    print(selected)
    chs_names = np.array(chs)[selected]
    print(chs_names)
    selected_patient.append(selected)


print(selected_patient)




